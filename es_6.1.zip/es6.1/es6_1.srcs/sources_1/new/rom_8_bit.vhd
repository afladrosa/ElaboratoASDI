----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 16:13:45
-- Design Name: 
-- Module Name: rom_8_bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rom_8_bit is
    Port ( clock : in STD_LOGIC;
           read : in STD_LOGIC;
           addr : in STD_LOGIC_VECTOR(3 downto 0);  -- supponeno di avere N=16 locazioni usiamo 4 bit per rappresentare gli indirizzi
           dato : out STD_LOGIC_VECTOR(7 downto 0));
end rom_8_bit;

architecture Behavioral of rom_8_bit is

-- definisco il tipo memory come un array costituito da 16 array ciascuno da 8 elementi
type memory is array (0 to 15) of std_logic_vector (7 downto 0);

-- definisco la costante rom16_8 che � di tipo memory -> ogni cella � inizializzata con un valore esadecimale
constant rom : memory := (
    x"11",   -- 00010001
    x"12",   -- 00010010
    x"14",   -- 00010100
    x"18",   -- 00011000
    x"21",   -- 00100001
    x"22",   -- 00100010
    x"24",   -- 00100100
    x"28",   -- 00101000
    x"41",   -- 01000001
    x"42",   -- 01000010
    x"44",   -- 01000100
    x"48",   -- 01001000
    x"81",   -- 10000001
    x"82",   -- 10000010
    x"84",   -- 10000100
    x"88"    -- 10001000
);

begin

    process(clock)
    begin
        if rising_edge(clock) then
            if read <= '1' then
                dato <= rom(to_integer(unsigned(addr)));
            end if;
        end if;
    end process;        

end Behavioral;
