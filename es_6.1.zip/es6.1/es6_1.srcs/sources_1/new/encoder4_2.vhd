----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 16:52:22
-- Design Name: 
-- Module Name: encoder4_2 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity encoder4_2 is
    Port ( in_enc : in STD_LOGIC_VECTOR (3 downto 0);
           out_enc : out STD_LOGIC_VECTOR (1 downto 0));
end encoder4_2;

architecture Behavioral of encoder4_2 is

begin

    out_enc <= "00" when in_enc = "0001" else
               "01" when in_enc = "0010" else
               "10" when in_enc = "0100" else
               "11" when in_enc = "1000";

end Behavioral;
