----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 17:21:13
-- Design Name: 
-- Module Name: sis_tot - Structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sis_tot is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           start : in STD_LOGIC;
           dato_out : out STD_LOGIC_VECTOR(3 downto 0));
end sis_tot;

architecture Structural of sis_tot is

component rom_8_bit is
    Port ( clock : in STD_LOGIC;
           read : in STD_LOGIC;
           addr : in STD_LOGIC_VECTOR(3 downto 0); 
           dato : out STD_LOGIC_VECTOR(7 downto 0));
end component rom_8_bit;

component mem_8_bit is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           write : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (3 downto 0);
           addr : in STD_LOGIC_VECTOR (3 downto 0);
           dato_out : out STD_LOGIC_VECTOR (3 downto 0));
end component mem_8_bit;

component M_enc_8_4 is
    Port ( dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           dato_out : out STD_LOGIC_VECTOR (3 downto 0));
end component M_enc_8_4;

component cont_mod_16 is
    Port ( abil : in STD_LOGIC;
           clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           addr_out : out STD_LOGIC_VECTOR (3 downto 0);
           umax : out STD_LOGIC);
end component cont_mod_16;

component control_unit is
    Port ( start : in STD_LOGIC;
           reset : in STD_LOGIC;
           umax : in STD_LOGIC;
           clock : in STD_LOGIC;
           read : out STD_LOGIC;
           write : out STD_LOGIC;
           abil_cont : out STD_LOGIC);
end component control_unit;

signal dato_out_rom : std_logic_vector(7 downto 0);
signal dato_in_mem : std_logic_vector(3 downto 0);
signal dato_out_mem : std_logic_vector(3 downto 0);
signal addr_tmp : std_logic_vector(3 downto 0);
signal read_tmp : std_logic := '0';
signal write_tmp : std_logic := '0';
signal abil_cont_tmp : std_logic := '0';
signal umax_tmp : std_logic := '0';

begin

    rom : rom_8_bit
    port map( clock => clock,
              read => read_tmp,
              addr => addr_tmp,
              dato => dato_out_rom
    );
    
    mem : mem_8_bit
    port map( clock => clock,
              reset => reset,
              write => write_tmp,
              dato_in => dato_in_mem,
              addr => addr_tmp,
              dato_out => dato_out_mem
    );
    
    M : M_enc_8_4
    port map( dato_in => dato_out_rom,
              dato_out => dato_in_mem
    );
    
    cont : cont_mod_16
    port map( abil => abil_cont_tmp,
              clock => clock,
              reset => reset,
              addr_out => addr_tmp,
              umax => umax_tmp
    );
    
    cu : control_unit
    port map( start => start,
              reset => reset,
              umax => umax_tmp,
              clock => clock,
              read => read_tmp,
              write => write_tmp,
              abil_cont => abil_cont_tmp
    );
    
    dato_out <= dato_out_mem;

end Structural;
