----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 16:42:03
-- Design Name: 
-- Module Name: cont_mod_16 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity cont_mod_16 is
    Port ( abil : in STD_LOGIC;
           clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           addr_out : out STD_LOGIC_VECTOR (3 downto 0);
           umax : out STD_LOGIC);
end cont_mod_16;

architecture Behavioral of cont_mod_16 is

signal counter : std_logic_vector (3 downto 0) := (others => '0');
signal umax_tmp : std_logic := '0';

begin

    process(clock) 
    begin
        if rising_edge(clock) then
            if reset = '1' then
                counter <= (others => '0');
                umax_tmp <= '0';
            elsif abil = '1' then
                if counter = "1111" then
                    counter <= (others => '0');
                    umax_tmp <= '1';
                else
                    counter <= std_logic_vector(unsigned(counter) + 1);
                    umax_tmp <= '0';
                end if;
            end if;
        end if;
    end process;
    
    addr_out <= counter;
    umax <= umax_tmp;

end Behavioral;
