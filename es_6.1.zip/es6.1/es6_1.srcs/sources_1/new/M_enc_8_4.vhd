----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 16:54:38
-- Design Name: 
-- Module Name: M_enc_8_4 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity M_enc_8_4 is
    Port ( dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           dato_out : out STD_LOGIC_VECTOR (3 downto 0));
end M_enc_8_4;

architecture Structural of M_enc_8_4 is

    component encoder4_2
        Port ( in_enc : in STD_LOGIC_VECTOR (3 downto 0);
               out_enc : out STD_LOGIC_VECTOR (1 downto 0));
    end component;

begin

    enc0 : encoder4_2
        Port map(in_enc(0) => dato_in(0),
                 in_enc(1) => dato_in(1),
                 in_enc(2) => dato_in(2),
                 in_enc(3) => dato_in(3),
                 out_enc(0) => dato_out(0),
                 out_enc(1) => dato_out(1));
                 
    enc1 : encoder4_2
        Port map(in_enc(0) => dato_in(4),
                 in_enc(1) => dato_in(5),
                 in_enc(2) => dato_in(6),
                 in_enc(3) => dato_in(7),
                 out_enc(0) => dato_out(2),
                 out_enc(1) => dato_out(3));

end Structural;
