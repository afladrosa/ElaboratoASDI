library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity calcolo_G_P is
     generic (      n: integer := 8       );
      Port (
            X: in std_logic_vector(n-1 downto 0);
            Y: in std_logic_vector(n-1 downto 0);
            G: out std_logic_vector(n-1 downto 0); -- condizioni di generazione
            P: out std_logic_vector(n-1 downto 0)  -- condizioni di propagazione

            );
    end calcolo_G_P;

architecture Behavioral of calcolo_G_P is

begin
     G_P: for i in 0 to n-1 generate
                G(i) <= X(i) and Y(i);
                P(i) <= X(i) or Y(i);
                
            end generate;

end Behavioral;
