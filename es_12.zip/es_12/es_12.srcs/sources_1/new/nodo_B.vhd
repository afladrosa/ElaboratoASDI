library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity nodo_B is
  Port ( 
        clock: in std_logic;
        reset: in std_logic;
        string_in: in std_logic_vector(3 downto 0);
        req_a: in std_logic;
        ack_b: out std_logic
  );
end nodo_B;

architecture Structural of nodo_B is

    signal write: std_logic;
    signal write_acc: std_logic;
    signal load_input: std_logic;
    signal read: std_logic;
    signal reset_count: std_logic;
    signal en_count: std_logic;
    signal umax: std_logic;
    signal count: std_logic_vector(2 downto 0);
    signal somma: std_logic_vector(3 downto 0);
    signal c: std_logic;
    signal uscita_R: std_logic_vector(3 downto 0);
    signal accumulatore: std_logic_vector(3 downto 0):= (others => '0'); -- mantiene la somma parziale 
    signal input_sommatore: std_logic_vector(3 downto 0):= (others => '0');

    
    component counter is
    generic(
        
        n: integer := 3 ;--numero di bit necessari
        modulo: integer := 8
        
        );
    
    Port ( clock : in  STD_LOGIC;
           reset : in  STD_LOGIC; --ingresso di reset per azzerare il contatore
		   enable : in STD_LOGIC; 
           umax: out STD_LOGIC; -- si alza quando si raggiunge il valore massimo di conteggio
           counter : out  STD_LOGIC_VECTOR (n-1 downto 0));
             
    end component;
    

    component CLA_adder is
        generic (N: natural range 0 to 32 := 4); 
        port(
            OP_A_CLA: in std_logic_vector(N-1 downto 0);
            OP_B_CLA: in std_logic_vector(N-1 downto 0);
            CIN_CLA: in std_logic; -- riporto entrante
            
            S_CLA: out std_logic_vector(N-1 downto 0);
            COUT_CLA: out std_logic -- riporto uscente
        );
    end component;
    
    
    component cu_B is 
	port( 
	      clock, reset: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      write: out std_logic;
	      write_acc: out std_logic;
	      load_input: out std_logic;
	      req_a: in std_logic;
	      ack_b: out std_logic
	      );
    end component;
    
    component Registro is
    Port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        write    : in  std_logic;
        data_in : in  std_logic_vector(3 downto 0);
        data_out: out std_logic_vector(3 downto 0)
    );
    end component;

begin
    
    

    
     cont: counter 
     generic map(
        
        n => 3 ,--numero di bit necessari
        modulo => 8
        
        )
    
    Port map ( clock => clock,
           reset => reset_count, --ingresso di reset per azzerare il contatore
		   enable => en_count, 
           umax => umax, -- si alza quando si raggiunge il valore massimo di conteggio
           counter => count   
    );
    
    
    cu: cu_B port map(
	      clock => clock,
	       reset => reset,
	      count => count,
	      en_count => en_count,
	      reset_count => reset_count,
	      read => read,
	      write => write,
	      write_acc=>write_acc,
	      load_input=>load_input,
	      req_a => req_a,
	      ack_b => ack_b
	      );
	      
	  
	cla: CLA_adder 
	port map(
		OP_A_CLA => input_sommatore,
		OP_B_CLA => accumulatore,
		CIN_CLA  => '0',
		
		S_CLA =>somma,
		COUT_CLA => c
	);
	
	R: Registro        -- in questo registro si scrive solo il risultato finale 
    Port map(
        clk  => clock,
        rst  => reset,
        write   => write,
        data_in  => accumulatore,
       data_out => uscita_R
    );
    
    ACC: Registro    -- in questo registro si scrivono le somme intermedie
    Port map(
        clk  => clock,
        rst  => reset,
        write   => write_acc,
        data_in  => somma,
        data_out => accumulatore
    );
    
    REG_INPUT: Registro        -- in questo registro si scrive il valore proveniente da A
    Port map(
        clk  => clock,
        rst  => reset,
        write   => load_input,
        data_in  => string_in,
       data_out => input_sommatore
    );
    
    
    

end Structural;
