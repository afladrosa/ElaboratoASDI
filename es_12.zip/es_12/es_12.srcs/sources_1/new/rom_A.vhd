library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity rom is
    port(
        clock   : in std_logic;
        read    : in std_logic;
        address : in std_logic_vector(2 downto 0);
        dout    : out std_logic_vector(3 downto 0)
    );
end entity rom;

architecture dataflow of rom is
    type MEMORY_8_4 is array (0 to 7) of std_logic_vector(3 downto 0);
    constant ROM_8_4 : MEMORY_8_4 := (
        "0000",  -- 0
        "0001",  -- 1
        "0010",  -- 2
        "0011",  -- 3
        "0100",  -- 4
        "0101",  -- 5
        "0110",  -- 6
        "0111"   -- 7
    );
begin
    main : process(clock)
    begin
        if rising_edge(clock) then
            if read = '1' then
                dout <= ROM_8_4(to_integer(unsigned(address)));
            end if;
        end if;
    end process main;
end architecture dataflow;
