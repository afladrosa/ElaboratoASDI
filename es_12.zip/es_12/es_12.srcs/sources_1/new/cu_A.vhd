library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity cu_A is 
	port( 
	      clock, reset, start: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      req_a: out std_logic;
	      ack_b: in std_logic
	      );
end cu_A;


architecture structural of cu_A is
	type state is (idle, S0, S1, S2,S3);
	-- idle: aspetta lo start
	-- S0 : d� il segnale di read
	-- S1: d� il segnale di req e aspetta l'ACK
	-- S2 : quando arriva l'ack, abbassa il segnale di req
	-- S3 : quando B abbassa l'ack, abilita il conteggio
	signal current_state,next_state: state;

	begin 

		
	reg_stato: process(clock)
			  begin
			  if(clock'event and clock='1') then
		         if(reset='1') then 
				    current_state <=idle;
			    else 
				    current_state <=next_state;
			     end if;
			  end if;
			  end process;
			  
	comb: process(current_state, start, ack_b)
		  begin
		  
		  	            
	     CASE current_state is
		  
		  WHEN idle => 
		  
		          en_count<='0';
		          reset_count<='1';
		          read<='0';
		          req_a<='0';
		          		          
                  if(start='1') then 
					   next_state <= S0;
				    else 
					   next_state <= idle;
					end if;
		
		  
		  WHEN S0 => 
		             
		            read<='1';
		            reset_count<='0';
					en_count<='0';
					
					next_state <= S1;
						
		 WHEN S1 => 
		            req_a<='1';
		            read<='0';
		            if ack_b='0' then
		              next_state<=S1;
		            elsif ack_b='1' then
		              next_state <= S2;    
		            end if;  
					     
		
		 WHEN S2 => 
                    req_a<='0';
		            
					if ack_b='1' then
					   next_state<=S2;
					elsif ack_b='0' then
					   next_state<=S3;
					 end if;
          
          when S3 =>
                    en_count<='1';
                    if count="111" then
                       next_state<=IDLE;
                    else
                        next_state<=S0;
                        
                     end if;
                 
		
         WHEN others =>
		      next_state <= idle;
		end CASE;
		
    end process; 
 end structural;