library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity nodo_A is
  Port ( 
        start: in std_logic;
        clock: in std_logic;
        reset: in std_logic;
        string_out: out std_logic_vector(3 downto 0);
        req_a: out std_logic;
        ack_b: in std_logic
   );
end nodo_A;

architecture Structural of nodo_A is
    
    signal en_count: std_logic;
    signal count: std_logic_vector(2 downto 0);
    signal read: std_logic;
    signal umax: std_logic;
    signal reset_count: std_logic;
    
    
    component rom is
    port(
        clock: in std_logic;
        read: in std_logic;
        address : in  std_logic_vector(2 downto 0);
        dout    : out std_logic_vector(3 downto 0)
    );
    end component;
    
    
    component counter is
    generic(
        
        n: integer := 3 ;--numero di bit necessari
        modulo: integer := 8
        
        );
    
    Port ( clock : in  STD_LOGIC;
           reset : in  STD_LOGIC; --ingresso di reset per azzerare il contatore
		   enable : in STD_LOGIC; 
           umax: out STD_LOGIC; -- si alza quando si raggiunge il valore massimo di conteggio
           counter : out  STD_LOGIC_VECTOR (n-1 downto 0));
             
    end component;
    
    
    component cu_A is 
	port( 
	      clock, reset, start: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      req_a: out std_logic;
	      ack_b: in std_logic
	      );
    end component;


begin
    rom_a: rom port map(
        clock=>clock,
        read=> read,
        address => count,
        dout  => string_out 
    );
    
    cont: counter 
     generic map(
        
        n => 3 ,--numero di bit necessari
        modulo => 8
        
        )
    
    Port map ( clock => clock,
           reset => reset_count, --ingresso di reset per azzerare il contatore
		   enable => en_count, 
           umax => umax, -- si alza quando si raggiunge il valore massimo di conteggio
           counter => count   
    );
   
   
   cu: cu_A port map(
	      clock => clock,
	      reset=> reset, 
	      start=> start,
	      count=> count,
	      en_count => en_count,
	      reset_count => reset_count,
	      read => read,
	      req_a => req_a,
	      ack_b=> ack_b
	      );
    
    


end Structural;
