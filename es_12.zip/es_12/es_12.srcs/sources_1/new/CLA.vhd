library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity calcolo_CLA is
     generic (      n: integer := 8       );
      Port (
            P: in std_logic_vector(n-1 downto 0);
            G: in std_logic_vector(n-1 downto 0);
            c_in_0: in std_logic; --riporto entrante (c0)
            C_out: out std_logic_vector(n downto 0)  -- riporti calcolati

            );
    end calcolo_CLA;

architecture Behavioral of calcolo_CLA is
    signal carry: std_logic_vector(n downto 0); -- segnale interno
        begin
            carry(0) <= c_in_0;
        
            cla: for i in 1 to n generate
                carry(i) <= G(i-1) or (P(i-1) and carry(i-1));
            end generate;
        
            C_out <= carry; -- assegnamento finale all'uscita
        end Behavioral;
        
