library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity Registro is
    Port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        write    : in  std_logic;
        data_in : in  std_logic_vector(3 downto 0);
        data_out: out std_logic_vector(3 downto 0)
    );
end Registro;

architecture Behavioral of Registro is
    signal reg : std_logic_vector(3 downto 0);
begin
    process(clk, rst)
    begin
        if rst = '1' then
            reg <= (others => '0');
        elsif rising_edge(clk) then
            if write = '1' then
                reg <= data_in;
            end if;
        end if;
    end process;
    data_out <= reg;
end Behavioral;
