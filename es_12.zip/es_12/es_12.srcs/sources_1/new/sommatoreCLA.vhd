library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity CLA_adder is
	generic (N: natural range 0 to 32 := 4); 
	port(
		OP_A_CLA: in std_logic_vector(N-1 downto 0);
		OP_B_CLA: in std_logic_vector(N-1 downto 0);
		CIN_CLA: in std_logic; -- riporto entrante
		
		S_CLA: out std_logic_vector(N-1 downto 0);
		COUT_CLA: out std_logic -- riporto uscente
	);
end CLA_adder;

architecture Structural of CLA_adder is
    
     signal G_temp: std_logic_vector(n-1 downto 0); -- condizioni di generazione
     signal P_temp: std_logic_vector(n-1 downto 0);  -- condizioni di propagazione
     signal C_temp: std_logic_vector(n downto 0); -- riporti calcolati dal livello cla
     signal C_FA_temp: std_logic_vector(N-1 downto 0);  -- appoggio per i riporti uscenti dai FA


	component myFA is
	   port(
		OP_A: in std_logic;
		OP_B: in std_logic;
		CIN: in std_logic;
	
		S: out std_logic;
		COUT: out std_logic
		);
	end component;
	
	component calcolo_G_P is
     generic (      n: integer := 4      );
      Port (
            X: in std_logic_vector(n-1 downto 0);
            Y: in std_logic_vector(n-1 downto 0);
            G: out std_logic_vector(n-1 downto 0); -- condizioni di generazione
            P: out std_logic_vector(n-1 downto 0)  -- condizioni di propagazione

            );
    end component;
	
	
	component calcolo_CLA is
     generic (      n: integer := 4       );
      Port (
            P: in std_logic_vector(n-1 downto 0);
            G: in std_logic_vector(n-1 downto 0);
            c_in_0: in std_logic; --riporto entrante (c0)
            C_out: out std_logic_vector(n downto 0)  -- riporti calcolati

            );
    end component;
	
begin
    
    COUT_CLA<=C_temp(n);
	
	 GP: calcolo_G_P 
        Generic map(
                n => 4     
                )
        Port map (
                X =>OP_A_CLA,
                Y => OP_B_CLA,
                G => G_temp,
                P => P_temp
                );
	
	CLA: calcolo_CLA 
     Generic map(
             n => 4       
             )
      Port map(
            P => P_temp,
            G => G_temp,
            c_in_0 => CIN_CLA,
            C_out => C_temp  
            );
	
		GEN_FA: for i in 0 to N-1 generate

            FA: myFA port map(
                OP_A => OP_A_CLA(i),
                OP_B => OP_B_CLA(i),
                CIN => C_temp(i),
                S => S_CLA(i),
                COUT => C_FA_temp(i)
            );
        end generate GEN_FA;
	
	
	
	
	
	end Structural;







