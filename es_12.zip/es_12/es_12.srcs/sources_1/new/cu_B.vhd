library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity cu_B is 
	port( 
	      clock, reset: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      write: out std_logic;
	      load_input: out std_logic;
	      write_acc: out std_logic; -- per scrivere nel registro ACC il risultato della somma corrente (per tutte le somme intermedie)
	      req_a: in std_logic;
	      ack_b: out std_logic
	      );
end cu_B;


architecture structural of cu_B is
	type state is (S0, S1, S2,S3, S4,S5,S6);
	
	signal current_state,next_state: state;

	begin 

		
	reg_stato: process(clock)
			  begin
			  if(clock'event and clock='1') then
		         if(reset='1') then 
				    current_state <=S0;
			    else 
				    current_state <=next_state;
			     end if;
			  end if;
			  end process;
			  
	comb: process(current_state, req_a)
		  begin
		  
		  	            
	     CASE current_state is
		  
		  WHEN S0 => 
		            write<='0';
		            write_acc<='0';
		            en_count<='0';
					if req_a='1' then
					   next_state <= S1;
					elsif req_a='0' then
					   next_state<=S0;
					end if;
						
		 WHEN S1 => 
		            ack_b<='1';
		            load_input<='1';
		            if req_a='1' then
		              next_state<=S1;
		            elsif req_a='0' then
		              next_state <= S2;    
		            end if;  

		 WHEN S2 =>
		          load_input<='0';
		          
		          next_state<=S3;
		 
		 WHEN S3 => 
		          write_acc<='1';     -- questo � il write nell'accumulatore dove memorizzo la somma corrente
		          next_state<=S4;
		          
		 WHEN S4 => 
		            write_acc<='0';
                    ack_b<='0'; -- indica "ho finito l'elaborazione di questa stringa"
                    en_count<='1'; 
                    if count="111" then 
		              next_state<=S5;
		            else 
		              next_state<=S0;
		            end if;
          
          when S5 =>
                    en_count<='0';
                    write<='1';     -- questo � il write nel registro R
                    next_state<=S6;
          
          when S6 =>
                    write<='0';
                    reset_count<='1';
                    next_state<=S0;
                    
                    
                    
                 
		
		end CASE;
		
    end process; 
 end structural;