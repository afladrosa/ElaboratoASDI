library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_com_handshaking is
end tb_com_handshaking;

architecture Behavioral of tb_com_handshaking is

    signal reset_a_tb    : std_logic := '0';
    signal reset_b_tb    : std_logic := '0';
    signal start_tb    : std_logic := '0';
    signal clock_a_tb  : std_logic := '0';
    signal clock_b_tb  : std_logic := '0';

    constant PERIOD_A_EQUAL   : time := 10 ns;
    constant PERIOD_B_EQUAL   : time := 10 ns;

    constant PERIOD_A_FAST    : time := 6 ns;
    constant PERIOD_B_SLOW    : time := 12 ns;

    constant PERIOD_A_SLOW    : time := 14 ns;
    constant PERIOD_B_FAST    : time := 7 ns;
    
    constant PHASE_SHIFT_B : time := 3 ns; -- sfasamento di clock_b rispetto a clock_a


    signal test_case : integer := 0;

    component com_handshaking is
        Port (
            start   : in std_logic;
            reset_a   : in std_logic;
            reset_b   : in std_logic;
            clock_a : in std_logic;
            clock_b : in std_logic
        );
    end component;

begin

    uut: com_handshaking
        port map (
            start   => start_tb,
            reset_a   => reset_a_tb,
            reset_b   => reset_b_tb,
            clock_a => clock_a_tb,
            clock_b => clock_b_tb
        );

    -- Processo clock A dinamico
    clk_a_process: process
    begin
        while true loop
            case test_case is
                when 0 => wait for PERIOD_A_EQUAL / 2;
                when 1 => wait for PERIOD_A_FAST / 2;
                when 2 => wait for PERIOD_A_SLOW / 2;
                when others => wait for 10 ns;
            end case;
            clock_a_tb <= not clock_a_tb;
        end loop;
    end process;

    -- Processo clock B dinamico
    clk_b_process: process
    begin
        --wait for PHASE_SHIFT_B;  -- sfasamento iniziale
        while true loop
            case test_case is
                when 0 => wait for PERIOD_B_EQUAL / 2;
                when 1 => wait for PERIOD_B_SLOW / 2;
                when 2 => wait for PERIOD_B_FAST / 2;
                when others => wait for 10 ns;
            end case;
            clock_b_tb <= not clock_b_tb;
        end loop;
    end process;

    -- Stimolo e sequenza dei test
    stim_proc: process
    begin
        -- Reset iniziale
        reset_a_tb <= '1';
        reset_b_tb <= '1';
        wait for 20 ns;
        reset_a_tb <= '0';
        reset_b_tb <= '0';

        --------------------------------
        -- Test 1: clock_a = clock_b
--        --------------------------------
--        test_case <= 0;
--        start_tb <= '1';
--        wait for 10 ns;
--        start_tb <= '0';
--        wait for 700 ns;

--        --------------------------------
--        -- Test 2: clock_a > clock_b
--        --------------------------------
        test_case <= 1;
        reset_a_tb <= '1';
        reset_b_tb <= '1';
        wait for 20 ns;
        reset_a_tb <= '0';
        reset_b_tb <= '0';
        start_tb <= '1';
        wait for 10 ns;
        start_tb <= '0';
        wait for 700 ns;

        --------------------------------
        -- Test 3: clock_b > clock_a
--        --------------------------------
        test_case <= 2;
        reset_a_tb <= '1';
        reset_b_tb <= '1';
        wait for 20 ns;
        reset_a_tb <= '0';
        reset_b_tb <= '0';
        start_tb <= '1';
        wait for 14 ns;
        start_tb <= '0';
        wait for 500 ns;

--        -- Fine simulazione
        wait;
    end process;

end Behavioral;


