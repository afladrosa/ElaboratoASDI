library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity cu_B is 
	port( 
	      clock, reset: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      write: out std_logic;
	      req_a: in std_logic;
	      ack_b: out std_logic
	      );
end cu_B;


architecture structural of cu_B is
	type state is (S0, S1, S2,S3,S4, fine_ricezione);
	

	signal current_state,next_state: state;

	begin 

		
	reg_stato: process(clock)
			  begin
			  if(clock'event and clock='1') then
		         if(reset='1') then 
				    current_state <=S0;
			    else 
				    current_state <=next_state;
			     end if;
			  end if;
			  end process;
			  
	comb: process(current_state, req_a)
		  begin
		  
		  	            
	     CASE current_state is
		  
		  WHEN S0 => 
		             
		            read<='0';
					en_count<='0';
					reset_count<='0';
					if req_a='1' then
					   next_state <= S1;
					elsif req_a='0' then
					   next_state<=S0;
					end if;
						
		 WHEN S1 =>                   -- avvio lettura
		            ack_b<='1';
		            read<='1';        
		            if req_a='1' then
		              next_state<=S1;
		            elsif req_a='0' then
		              next_state <= S2;    
		            end if;  
					     
		WHEN S2 =>
		          read<='0';          -- dato pronto
		          next_state<=S3;
		 
		 WHEN S3 => 
		            -- i dati sono pronti: avvio la scrittura
                    write<='1';
		            next_state<=S4;
          
          when S4 =>
                    ack_b<='0';         -- INVECE DI USARE UN ULTERIORE SEGNALE DI DONE, SI MANTIENE ALTO L'ACK FINO A CHE L'ELABORAZIONE NON E' FINITA
                    
                    en_count<='1';
                    write<='0';
                    if count = "111" then 
                        next_state<=fine_ricezione;
                    else
                         next_state<=S0;
                    end if;
          
          when fine_ricezione =>
                    reset_count<='1';
                    en_count<='0';
                    next_state<=S0;
                    
                    
                    
                 
		
		end CASE;
		
    end process; 
 end structural;