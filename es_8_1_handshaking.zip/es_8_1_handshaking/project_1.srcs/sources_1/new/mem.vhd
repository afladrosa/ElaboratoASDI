library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;

entity mem is
    port(
        CLK: in std_logic;
        RST: in std_logic;
        write: in std_logic; -- Segnale di scrittura
        read: in std_logic;  -- Segnale di lettura
        ADDR : in std_logic_vector(2 downto 0);
        data_in: in std_logic_vector(7 downto 0);
        data_out: out std_logic_vector(7 downto 0) -- Uscita dati
    );
end mem;

architecture Behavioral of mem is
    type mem_type is array (0 to 7) of std_logic_vector(7 downto 0);
    signal MEM : mem_type := (
        0 => "00000000", -- 0
        1 => "00000001", -- 1
        2 => "00000010", -- 2
        3 => "00000011", -- 3
        4 => "00000100", -- 4
        5 => "00000101", -- 5
        6 => "00000110", -- 6
        7 => "00000111"  -- 7
    );
    signal temp_out : std_logic_vector(7 downto 0) := (others => '0');
begin

    process(CLK)
    begin
        if rising_edge(CLK) then
            if RST = '1' then  -- Reset sincrono: azzera tutta la memoria
                for i in 0 to 7 loop
                     MEM(i) <= std_logic_vector(to_unsigned(i, 8));
                end loop;
                temp_out <= (others => '0');
            else
                if write = '1' then  -- Scrittura
                    MEM(conv_integer(ADDR)) <= data_in;
                end if;
                if read = '1' then   -- Lettura
                    temp_out <= MEM(conv_integer(ADDR));
                end if;
            end if;
        end if;
    end process;

    data_out <= temp_out;

end Behavioral;
