library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity nodo_B is
  Port ( 
        clock: in std_logic;
        reset: in std_logic;
        string_in: in std_logic_vector(7 downto 0);
        req_a: in std_logic;
        ack_b: out std_logic
  );
end nodo_B;

architecture Structural of nodo_B is

    signal write: std_logic;
    signal read: std_logic;
    signal reset_count: std_logic;
    signal en_count: std_logic;
    signal umax: std_logic;
    signal count: std_logic_vector(2 downto 0);
    signal somma: std_logic_vector(7 downto 0);
    signal string_b: std_logic_vector(7 downto 0);
    signal ov: std_logic;
    signal c: std_logic;

    component mem is
    port(
        CLK: in std_logic;
        RST: in std_logic;
        write: in std_logic; -- Segnale di scrittura
        read: in std_logic; -- Segnale di lettura
        ADDR : in std_logic_vector(2 downto 0);
        data_in: in std_logic_vector(7 downto 0);
        data_out: out std_logic_vector(7 downto 0)
    );
    end component;
    
    component counter is
    generic(
        
        n: integer := 3 ;--numero di bit necessari
        modulo: integer := 8
        
        );
    
    Port ( clock : in  STD_LOGIC;
           reset : in  STD_LOGIC; --ingresso di reset per azzerare il contatore
		   enable : in STD_LOGIC; 
           umax: out STD_LOGIC; -- si alza quando si raggiunge il valore massimo di conteggio
           counter : out  STD_LOGIC_VECTOR (n-1 downto 0));
             
    end component;
    
    component RCA_Nbit is
	generic (N: natural range 0 to 32 := 8); 
	port(
		OP_A_RCA: in std_logic_vector(N-1 downto 0);
		OP_B_RCA: in std_logic_vector(N-1 downto 0);
		CIN_RCA: in std_logic;
		
		S_RCA: out std_logic_vector(N-1 downto 0);
		COUT_RCA: out std_logic;
		OV: out std_logic
	);
    end component;
    
    
    component cu_B is 
	port( 
	      clock, reset: in std_logic;
	      count: in std_logic_vector (2 downto 0);
	      en_count: out std_logic;
	      reset_count: out std_logic;
	      read: out std_logic;
	      write: out std_logic;
	      req_a: in std_logic;
	      ack_b: out std_logic
	      );
    end component;

begin
    
    
    mem_b:  mem port map (
        CLK => clock,
        RST => reset,
        write => write,
        read=> read,
        ADDR  => count,
        data_in => somma,
        data_out => string_b
    );
    
     cont: counter 
     generic map(
        
        n => 3 ,--numero di bit necessari
        modulo => 8
        
        )
    
    Port map ( clock => clock,
           reset => reset_count, --ingresso di reset per azzerare il contatore
		   enable => en_count, 
           umax => umax, -- si alza quando si raggiunge il valore massimo di conteggio
           counter => count   
    );
    
    
    cu: cu_B port map(
	      clock => clock,
	       reset => reset,
	      count => count,
	      en_count => en_count,
	      reset_count => reset_count,
	      read => read,
	      write => write,
	      req_a => req_a,
	      ack_b => ack_b
	      );
	      
	  
	rca: RCA_Nbit 
	port map(
		OP_A_RCA =>string_in,
		OP_B_RCA => string_b,
		CIN_RCA => '0',
		
		S_RCA =>somma,
		COUT_RCA => c,
		OV => ov
	);
    

end Structural;
