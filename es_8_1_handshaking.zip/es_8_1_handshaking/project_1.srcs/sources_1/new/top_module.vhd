library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity com_handshaking is
  Port ( 
        start: in std_logic; 
        reset_a: in std_logic;
        reset_b: in std_logic;
        clock_a: in std_logic;
        clock_b: in std_logic

        );
end com_handshaking;

architecture Structural of com_handshaking is

  signal req_a: std_logic;
  signal ack_b: std_logic;
  signal string_a:  std_logic_vector(7 downto 0);
  
  component nodo_B is
  Port ( 
        clock: in std_logic;
        reset: in std_logic;
        string_in: in std_logic_vector(7 downto 0);
        req_a: in std_logic;
        ack_b: out std_logic
  );
   end component;
   
  component nodo_A is
  Port ( 
        start: in std_logic;
        clock: in std_logic;
        reset: in std_logic;
        string_out: out std_logic_vector(7 downto 0);
        req_a: out std_logic;
        ack_b: in std_logic
   );
   end component;
    

begin

  A: nodo_A
  Port map(
           
        start => start,
        clock => clock_a,
        reset => reset_a,
        string_out => string_a,
        req_a => req_a,
        ack_b => ack_b
   );
  
  B: nodo_B 
  Port map( 
        clock => clock_b,
        reset => reset_b,
        string_in => string_a,
        req_a => req_a,
        ack_b => ack_b
  );
    


end Structural;