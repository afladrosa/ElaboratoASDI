library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity tb_sistema_complessivo is
end tb_sistema_complessivo;

architecture behavior of tb_sistema_complessivo is

    -- Component declaration
    component sistema_complessivo
        Port ( 
            stop: in std_logic;
            clock: in std_logic;
            reset: in std_logic;
            set: in std_logic;
            minutes_in: in std_logic_vector(5 downto 0);
            seconds_in: in std_logic_vector(5 downto 0);
            hours_in: in std_logic_vector(4 downto 0);
            seconds_out: out std_logic_vector(5 downto 0);
            minutes_out: out std_logic_vector(5 downto 0);
            hours_out: out std_logic_vector(4 downto 0)
        );
    end component;

    -- Signal declaration
    signal stop       : std_logic := '0';
    signal clock      : std_logic := '0';
    signal reset      : std_logic := '0';
    signal set        : std_logic := '0';
    signal minutes_in : std_logic_vector(5 downto 0) := (others => '0');
    signal seconds_in : std_logic_vector(5 downto 0) := (others => '0');
    signal hours_in   : std_logic_vector(4 downto 0) := (others => '0');
    signal seconds_out: std_logic_vector(5 downto 0);
    signal minutes_out: std_logic_vector(5 downto 0);
    signal hours_out  : std_logic_vector(4 downto 0);

    -- Clock period
    constant clk_period : time := 10 ns;

begin

    -- Instantiate the Unit Under Test (UUT)
    uut: sistema_complessivo Port Map (
        stop => stop,
        clock => clock,
        reset => reset,
        set => set,
        minutes_in => minutes_in,
        seconds_in => seconds_in,
        hours_in => hours_in,
        seconds_out => seconds_out,
        minutes_out => minutes_out,
        hours_out => hours_out
    );

    -- Clock process
    clk_process :process
    begin
        clock <= '0';
        wait for clk_period/2;
        clock <= '1';
        wait for clk_period/2;
    end process;

    -- Stimulus process
    stim_proc: process
    begin
        -- Reset
        reset <= '1';
        wait for 20 ns;
        reset <= '0';


        -- Wait and observe normal operation
        wait for 200 ns;

        -- Attiva il segnale di stop per prendere il primo intertempo
        stop <= '1';
        wait for 10 ns;

        -- Disattiva stop
        stop <= '0';
        

        -- Attendi un altro po' per vedere il comportamento
        wait for 100 ns;
        
       -- TEST 2: Cambia il valore con il set durante il conteggio
        set <= '1';
        hours_in <= "10111";   -- 23 ore
        minutes_in <= "111011"; -- 59 minuti
        seconds_in <= "111000"; -- 56 secondi
        wait for 10 ns;
        set <= '0';
       
        wait for 10 ns;
        stop<='1';
        wait for 10 ns;
        stop<='0';
        
        
        wait for 105 ns;
        stop<='1';
        wait for 10 ns;
        stop<='0';
        
        -- Termina simulazione
        wait;
    end process;

end behavior;
