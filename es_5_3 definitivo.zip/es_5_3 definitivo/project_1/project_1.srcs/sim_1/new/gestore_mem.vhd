library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- questo gestore della memoria si occupa di dare il segnale di write alla memoria

entity gestore_mem is
  Port (
        stop: in std_logic;
        clock: in std_logic;
        reset: in std_logic;
        write: out std_logic;
        en_count: out std_logic;
        count: STD_LOGIC_VECTOR (3 downto 0)
     );
end gestore_mem;

architecture Behavioral of gestore_mem is
    type state is (idle, scrivi, fine);




signal current_state,next_state: state;

	begin 

		
	reg_stato: process(clock)
			  begin
			  if(clock'event and clock='1') then
		         if(reset='1') then 
				    current_state <=idle;
			    else 
				    current_state <=next_state;
			     end if;
			  end if;
			  end process;
			  
			  
    comb: process(current_state,stop)
		  begin
		  
		  	            
	     CASE current_state is
		  
		  WHEN idle => 
		      write<='0';
		      en_count<='0';
		      if stop = '1' then
        			next_state<=scrivi;
        			
        	   else
        	       next_state<=idle;
        	    end if;
		          
		  WHEN scrivi =>
		      write<='1';
		      en_count<='1';
		      if count="1111" then
		          next_state<=fine;
		      else 
		          next_state<=idle;
               end if;
		      			
		
		      
     
        when fine =>
              write <='0';
		      en_count<='0';
                
		
		end CASE;
	end process;
--main: process(clock)
--begin

--	if rising_edge(clock) then
--	   if reset = '1' then
--		  write<='0';
--	   else
--		  if stop = '1' then
--			write<='1';
--		  else
--		      write<='0';
--	       end if;
--	   end if;
--	end if;

--end process;


end Behavioral;
