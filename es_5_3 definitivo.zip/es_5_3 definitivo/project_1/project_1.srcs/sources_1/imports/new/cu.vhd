library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity control_unit is
    Port ( 
        clock       : in  STD_LOGIC;
        reset       : in  STD_LOGIC;
        load        : in  STD_LOGIC;  -- gi� debounced
        seconds_in  : in  STD_LOGIC_VECTOR(5 downto 0);
        minutes_in  : in  STD_LOGIC_VECTOR(5 downto 0);
        hours_in    : in  STD_LOGIC_VECTOR(4 downto 0);
        seconds_out : out STD_LOGIC_VECTOR(5 downto 0);
        minutes_out : out STD_LOGIC_VECTOR(5 downto 0);
        hours_out   : out STD_LOGIC_VECTOR(4 downto 0)
    );
end control_unit;

architecture Behavioral of control_unit is


    type stato is (S_LOAD_SEC, S_LOAD_MIN, S_LOAD_HOUR);
    signal stato_corrente, stato_prossimo : stato := S_LOAD_SEC;
    signal reg_value : STD_LOGIC_VECTOR(16 downto 0) := (others => '0');



    -- Segnali per rilevamento fronte
    signal load_prev_sync : STD_LOGIC := '0';
    signal load_rise      : STD_LOGIC := '0';

begin

    seconds_out <= reg_value(5 downto 0); 
    minutes_out <= reg_value(11 downto 6); 
    hours_out   <= reg_value(16 downto 12); 

    -- Processo rilevamento fronte di salita
    process(clock)
        begin
            if rising_edge(clock) then
                if (load = '1' and load_prev_sync = '0') then
                    load_rise <= '1';
                else
                    load_rise <= '0';
                end if;
        
                load_prev_sync <= load;
            end if;
    end process;



    process(stato_corrente, load_rise)
    begin
        case stato_corrente is
            when S_LOAD_SEC =>
                
                if load_rise = '1' then
                    stato_prossimo <= S_LOAD_MIN;
                   
                else
                    stato_prossimo <= S_LOAD_SEC;
                end if;

            when S_LOAD_MIN =>
                if load_rise = '1' then
                    stato_prossimo <= S_LOAD_HOUR;
                else
                    stato_prossimo <= S_LOAD_MIN;
                end if;

            when S_LOAD_HOUR =>
            
                if load_rise = '1' then
                    stato_prossimo <= S_LOAD_SEC;
                else
                    stato_prossimo <= S_LOAD_HOUR;
                end if;
        end case;
    end process;


    process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                stato_corrente <= S_LOAD_SEC;
                reg_value <= (others => '0');
            else
                stato_corrente <= stato_prossimo;

                
                    case stato_corrente is
                        when S_LOAD_SEC =>
                            if load_rise = '1' then
                                reg_value(5 downto 0) <= seconds_in;
                             end if;

                        when S_LOAD_MIN =>
                             if load_rise = '1' then
                                 reg_value(11 downto 6) <= minutes_in;
                             end if;

                        when S_LOAD_HOUR =>
                             if load_rise = '1' then
                                 reg_value(16 downto 12) <= hours_in;
                              end if;
                            
                    end case;
                
            end if;
        end if;
    end process;

end Behavioral;
