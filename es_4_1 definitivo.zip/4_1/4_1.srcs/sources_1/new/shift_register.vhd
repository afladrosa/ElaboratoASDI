-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;


--BEHAVIOURAL

library ieee;
use ieee.std_logic_1164.all;

entity shift_register is
    generic(
        N: integer :=4 -- valore di default = 4
        );
    port(CLK, RST: in std_logic;
         Ei : in std_logic; --ingresso seriale esterno da sinistra (per lo shift a destra)
         Eo : in std_logic; --ingresso seriale esterno da destra (per lo shift a sinistra)
         SEL : in std_logic_vector(1 downto 0); -- selezione di direzione e numero di posizioni dello shift
                                                -- S= 00 -> shift a destra di una posizione
                                                -- S= 01 -> shift a destra di due posizioni
                                                -- S= 10 -> shift a sinistra di una posizione
                                                -- S= 11 -> shift a sinistra di due posizioni
         SO : out std_logic);
end shift_register;

architecture archi of shift_register is
    signal tmp: std_logic_vector(N-1 downto 0);
begin

    process (CLK)
    begin
        if (CLK'event and CLK='1') then
            if (RST='1') then
                tmp <= (others=>'0');
            else
                case SEL is
                    when "00" => -- shift a destra di una posizione
                        --questi segnali vengono aggiornati con i valori che avevano alla fine della 
                        -- precedente attivazione
                        tmp(0)<=Ei;
                        for i in 1 to (N-1) loop
                            tmp(i)<=tmp(i-1);
                        end loop;
                        
                     when "01" => -- shift a destra di due posizioni
                        tmp(0)<=Ei;
                        tmp(1)<=Ei; -- si � scelto si "replicare" il valore dell'ingresso nei due bit
                        for i in 2 to (N-1) loop
                            tmp(i)<=tmp(i-2);
                        end loop;
                     
                     when "10" => -- shift a sinistra di una posizione
                        
                        tmp(N-1)<=Eo;
                        for i in N-2 downto 0 loop
                            tmp(i)<=tmp(i+1);
                        end loop;
                      
                      when "11" => -- shift a sinistra di due posizioni
                         tmp(N-1)<=Eo; 
                         tmp(N-2)<=Eo; -- si � scelto si "replicare" il valore dell'ingresso nei due bit
                        for i in N-3 downto 0 loop
                            tmp(i)<=tmp(i+2);
                        end loop;
                        
                       when others =>
                            tmp <= (others => '0');
                       
                       
                        
                                
               -- SO <= tmp(N-1);  --se inserisco qui questa istruzione invece che fuori dal process,
                               --l'uscita SO non viene aggiornata contestualmente a tmp(3) 
                               --ci vorr� un altro fronte del clock per vedere SO e quindi, per conservare
                               --il valore di tmp(3) fino al prossimo clock, verr� inserito un altro flip-flop
                               --tra tmp(3) e SO      
                end case;
            end if;
            
        end if;
        --SO <= tmp(N-1);  --se inserisco qui questa istruzione, il valore di SO � aggiornato alla prossima
                       --attivazione del process, quindi sul fronte di discesa successivo a quando � stato
                       --aggiornato tmp(3)
      end process;
      SO <= tmp(N-1);  --se inserisco qui questa istruzione, il valore di SO viene aggiornato continuamente
                       --in maniera concorrente
    

end archi;




    
