library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity cronometro_tb is
end cronometro_tb;

architecture testbench of cronometro_tb is
    -- Dichiarazione segnali
    signal clock       : std_logic := '0';
    signal reset       : std_logic := '0';
    signal set         : std_logic := '0';
    signal minutes_in  : std_logic_vector(5 downto 0) := "000000";
    signal seconds_in  : std_logic_vector(5 downto 0) := "000000";
    signal hours_in    : std_logic_vector(4 downto 0) := "00000";
    signal minutes_out : std_logic_vector(5 downto 0);
    signal seconds_out : std_logic_vector(5 downto 0);
    signal hours_out   : std_logic_vector(4 downto 0);

    -- Instanziazione del cronometro
    component cronometro
        Port ( 
            clock       : in std_logic;
            reset       : in std_logic;
            set         : in std_logic;
            minutes_in  : in std_logic_vector(5 downto 0);
            seconds_in  : in std_logic_vector(5 downto 0);
            hours_in    : in std_logic_vector(4 downto 0);
            minutes_out : out std_logic_vector(5 downto 0);
            seconds_out : out std_logic_vector(5 downto 0);
            hours_out   : out std_logic_vector(4 downto 0)
        );
    end component;

begin
    -- Collegamento segnali
    UUT: cronometro 
        port map(
            clock       => clock,
            reset       => reset,
            set         => set,
            minutes_in  => minutes_in,
            seconds_in  => seconds_in,
            hours_in    => hours_in,
            minutes_out => minutes_out,
            seconds_out => seconds_out,
            hours_out   => hours_out
        );

    -- Generazione del clock 100 MHz (10 ns periodo)
    process
    begin
        while true loop
            clock <= '0';
            wait for 5 ns;
            clock <= '1';
            wait for 5 ns;
        end loop;
    end process;

 
    -- Stimolo di test
    process
    begin
        -- Reset iniziale
       -- reset <= '1';
       -- wait for 10 ns;
        reset <= '0';
        -- Lascia contare per un po'


        -- Lascia contare per un po'
        wait for 500 ns;
        
        -- TEST 2: Cambia il valore con il set durante il conteggio
        set <= '1';
        hours_in <= "10111";   -- 23 ore
        minutes_in <= "111011"; -- 59 minuti
        seconds_in <= "111000"; -- 56 secondi
        wait for 10 ns;
        set <= '0';

        -- Lascia contare per un po'
        wait for 1 us;

        -- Fine simulazione
        wait;
    end process;

end testbench;
