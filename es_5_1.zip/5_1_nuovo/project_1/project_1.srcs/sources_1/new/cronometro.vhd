library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity cronometro is 
    Port ( 
        clock: in std_logic;
        reset: in std_logic;
        set: in std_logic;
        minutes_in: in std_logic_vector(5 downto 0);
        seconds_in: in std_logic_vector(5 downto 0);
        hours_in: in std_logic_vector(4 downto 0);
        
        seconds_out: out std_logic_vector(5 downto 0);
        minutes_out: out std_logic_vector(5 downto 0);
        hours_out: out std_logic_vector(4 downto 0)
         
    );
end cronometro;

architecture Structural of cronometro is
    signal enable_sec: std_logic :='0';  
    signal enable_min: std_logic := '0';
    signal enable_h: std_logic := '0';
    signal umax_sec: std_logic :='0';
    signal umax_min: std_logic :='0';
    signal umax_h: std_logic :='0';
  
    
    component counter is
     
        generic(
            
            n: integer := 3 ;--numero di bit necessari
            modulo: integer := 8
            
            );
        
        Port ( clock : in  STD_LOGIC;
               reset : in  STD_LOGIC; --ingresso di reset per azzerare il tempo
               set : in STD_LOGIC; --ingresso di set
               set_value : in STD_LOGIC_VECTOR (n-1 downto 0); -- ingresso di set per inizializzare il cronometro a un valore iniziale
               enable : in STD_LOGIC; --questo � l'enable del clock, insieme danno l'impulso di conteggio
               umax: out STD_LOGIC; -- si alza quando si raggiunge il valore massimo di conteggio
               counter : out  STD_LOGIC_VECTOR (n-1 downto 0)
               );
               
               
        end component;
        
  
      component clock_divider is
         generic(
                    clock_frequency_in : integer := 100000000;--100MHz
                    clock_frequency_out : integer := 10000000 --1 Hz : frequenza desiderata
                    );
        Port ( clock_in : in  STD_LOGIC;
               reset : in STD_LOGIC;
               clock_out : out  STD_LOGIC); -- nb: � un segnale di logica e non un clock -> viene usato come abilitazione
       end component;
       
       

begin
        DIV: clock_divider
            generic map(
            clock_frequency_in => 100000000,--100MHz
            clock_frequency_out => 10000000
            )
            port map(
                clock_in=>clock,
                reset=>reset,
                clock_out=>enable_sec
            );
    
        COUNT_SEC: counter
           generic map(
            n => 6,
            modulo=> 60
            )
        
            port map( 
               clock => clock,
               reset => reset,
               set =>set,
               set_value => seconds_in,
               enable => enable_sec, 
               umax => umax_sec,
               counter => seconds_out
        );
        
        enable_min <= umax_sec and enable_sec;
        
        
        COUNT_MIN: counter 
           generic map(
            n => 6,
            modulo=> 60
            )
        
            port map( 
               clock => clock,
               reset => reset,
               set =>set,
               set_value => minutes_in,
               enable => enable_min,
               umax => umax_min,
               counter => minutes_out
        );
        
        enable_h <=  umax_sec and umax_min and enable_sec;
        
        COUNT_H: counter 
           generic map(
            n => 5,
            modulo=> 24
            )
        
            port map( 
               clock => clock,
               reset => reset,
               set =>set,
               set_value => hours_in,
               enable => enable_h,
               umax => umax_h,
               counter => hours_out
        );
   
   
        


end Structural;
