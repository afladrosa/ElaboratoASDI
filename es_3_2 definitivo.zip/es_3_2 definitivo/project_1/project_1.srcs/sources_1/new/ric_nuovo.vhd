library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity Riconoscitore_2 is
	port( i: in std_logic;
		  RST, CLK: in std_logic;
		  Y: out std_logic;
		  M: in std_logic;
		  LOAD_I_CLEARED: in std_logic;
		  LOAD_M_CLEARED: in std_logic;
		  stato_out: out std_logic_vector(3 downto 0)
	);
end Riconoscitore_2;

architecture Behavioral_2proc of Riconoscitore_2 is

type stato is (IDLE, S0, S1, S2, Q0, Q1, Q2, Q3, Q4);

signal stato_corrente : stato := IDLE;
signal stato_prossimo : stato;
signal last_mode : std_logic := '0';

signal Ytemp : std_logic;
signal m_temp: std_logic;
signal i_temp: std_logic;
signal first_m: std_logic:='0';
signal i_valid : std_logic := '0';


begin


stato_uscita: process(stato_corrente)

begin
    case stato_corrente is
        WHEN IDLE =>
            --if first_m='0' then stato_prossimo<=IDLE; 
           -- else
                if m='1' then
                    stato_prossimo <= S0;
                elsif m_temp='0' then
                    stato_prossimo <= Q0;
                else 
                    stato_prossimo<=IDLE;
               end if;
           -- end if;
         
         WHEN S0 =>
           -- if i_valid='1' then
                if i_temp='0' then
                    stato_prossimo<=S0;
                    Ytemp<='0';
                elsif i_temp='1'then 
                    stato_prossimo<=S1;
                    Ytemp<='0';
                end if;
            --else stato_prossimo<=S0;
            --end if;
            
        
        WHEN S1 =>
            if i_temp='0' then
                stato_prossimo<=S2;
                Ytemp<='0';
            elsif i_temp='1' then
                stato_prossimo<=S1;
                Ytemp<='0';
            end if;
        WHEN S2 =>
            if i_temp='0' then
                stato_prossimo<=S0;
                Ytemp<='0';
            elsif i_temp='1' then
                stato_prossimo<=S0;
                Ytemp<='1';
             end if;
         
         WHEN Q0 =>
            --if i_valid='1' then
                if i_temp='0' then
                    stato_prossimo<=Q1;
                    Ytemp<='0';
                elsif i_temp='1' then
                    stato_prossimo<=Q3;
                    Ytemp<='0';
                end if;
             --else
              --  stato_prossimo<=Q0;
             -- end if;
         
         
         WHEN Q1 => 
            stato_prossimo <= Q2;
            Ytemp<='0';
         
         WHEN Q2 =>
            stato_prossimo <= Q0;
            Ytemp<='0';
         
         WHEN Q3 =>
            if i_temp='1' then
                stato_prossimo <= Q2;
                Ytemp<='0';
            elsif i_temp='0' then
                stato_prossimo <= Q4;
                Ytemp<='0';
            end if;
          
          WHEN Q4 =>
            if i_temp='1' then
                stato_prossimo<=Q0;
                Ytemp<='1';
            elsif i_temp='0' then
                stato_prossimo<=Q0;
                Ytemp<='0';
            end if;   
         
         
         
         end case;               
       


end process;



-- questo processo rappresenta gli elementi di memoria 
--mem: process (CLK)
--begin
--	if( CLK'event and CLK = '1' ) then
--		if( RST = '1') then
--	       stato_corrente <= IDLE;
--	       first_m<='0';
	  
--	    else	
	    
--	       if LOAD_I_CLEARED='1' then i_temp<=i;
--	           stato_corrente<=stato_prossimo;
--	        end if;
	       
--	       if LOAD_M_CLEARED='1' then 
--	           m_temp<=m;
--	           if first_m='0' then 
--	               first_m<='1';
--	               last_mode<=m_temp; 
--	           elsif m_temp/=last_mode then
--	               if m_temp='1' then 
--	                   stato_corrente<=S0;
--	               elsif m_temp='0' then 
--	                   stato_corrente<=Q0;
--	               end if;
--	               last_mode<=m_temp;
--	          else
--	               stato_corrente<=stato_prossimo;
	               
--	            end if;
	               
	               
--	        end if;
	       
	       
--	       Y<=Ytemp;
	      
--   end if;
--   end if;
--end process;


mem: process (CLK)
begin
	if( CLK'event and CLK = '1' ) then
		if( RST = '1') then
	       stato_corrente <= IDLE;
	      -- first_m<='0';
           Y<='0';	 
          -- i_valid <= '0';  -- invalida i_temp 
	    else	
	    
	       if LOAD_I_CLEARED='1' then 
	           --i_temp<=i;
	           stato_corrente<=stato_prossimo;
	          -- i_valid <= '1';
	        end if;
	       
	       if LOAD_M_CLEARED='1' then 
	           m_temp<=m;
	           if first_m='0' then 
	               first_m<='1';
	               last_mode<=m; 
	           elsif m/=last_mode then
	               if m='1' then 
	                   stato_corrente<=S0;
	               elsif m='0' then 
	                   stato_corrente<=Q0;
	               end if;
	               last_mode<=m;
	               i_valid <= '0';  -- Invalida i_temp sul cambio di m
	          else
	               stato_corrente<=stato_prossimo;
	               
	            end if;
	               
	               
	        end if;
	       
	       
	       Y<=Ytemp;
	      
   end if;
   end if;
end process;


with stato_corrente select
    stato_out <= "0000" when IDLE,
                 "0001" when S0,
                 "0010" when S1,
                 "0011" when S2,
                 "0100" when Q0,
                 "0101" when Q1,
                 "0110" when Q2,
                 "0111" when Q3,
                 "1000" when Q4,
                 "1111" when others;


end Behavioral_2proc;


