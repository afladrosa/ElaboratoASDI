library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity riconoscitore_on_board is
     Port (
          I: in std_logic;
		  RST, CLK: in std_logic;
		  output: out std_logic;
		  M: in std_logic;
		  LOAD_I: in std_logic;
		  LOAD_M: in std_logic;
		  debug: out std_logic_vector(3 downto 0)
		  
      );
end riconoscitore_on_board;

architecture Structural of riconoscitore_on_board is
        component ButtonDebouncer is
            generic (                       
                CLK_period: integer := 10;  -- periodo del clock (della board) 
-- in nanosecondi
                btn_noise_time: integer := 10000000 -- durata stimata dell'oscillazione
-- del bottone in nanosecondi
                                                    -- il valore di default � 10 ms
            );
            Port ( RST : in STD_LOGIC;
                   CLK : in STD_LOGIC;
                   BTN : in STD_LOGIC;
                   CLEARED_BTN : out STD_LOGIC);
        end component;
        
        component Riconoscitore is
            port( i: in std_logic;
                  RST, CLK: in std_logic;
                  Y: out std_logic;
                  M: in std_logic;
                  LOAD_I_CLEARED: in std_logic;
                  LOAD_M_CLEARED: in std_logic;
                  stato_out: out std_logic_vector(3 downto 0)
            );
        end component;
        



    signal LOAD_I_CLEARED: std_logic;
    signal LOAD_M_CLEARED: std_logic;
    signal stato: std_logic_vector(3 downto 0);

    
    
begin

-- Occorrono due button debouncer: uno per I e uno per M
    BD_I: ButtonDebouncer generic map (
            CLK_period => 10,
             btn_noise_time => 10000000
                )
              port map(
                    RST => RST,
                    CLK => CLK,
                    BTN => LOAD_I,
                    CLEARED_BTN => LOAD_I_CLEARED
    );
    
    BD_M: ButtonDebouncer generic map (
            CLK_period => 10,
             btn_noise_time => 10000000
                )
              port map(
                    RST => RST,
                    CLK => CLK,
                    BTN => LOAD_M,
                    CLEARED_BTN => LOAD_M_CLEARED
    );
    
    
    Riconoscitore_2modalita: Riconoscitore port map(
                  i => I,
                  RST => RST,
                  CLK =>CLK,
                  Y => output,
                  M => M,
                  LOAD_I_CLEARED =>LOAD_I_CLEARED,
		     LOAD_M_CLEARED=>LOAD_M_CLEARED,
		     stato_out => stato

    );
    
    
    debug<=stato;

end Structural;
