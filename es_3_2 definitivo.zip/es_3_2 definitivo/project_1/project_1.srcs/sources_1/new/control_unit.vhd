----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08.03.2025 17:44:23
-- Design Name: 
-- Module Name: control_unit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity control_unit is
       Port(
           I: in std_logic;
		  RST, CLK: in std_logic;
		  I_OUT: out std_logic;
		  M_OUT: out std_logic;
		  M: in std_logic;
		  LOAD_I_CLEARED: in std_logic;
		  LOAD_M_CLEARED: in std_logic
		  );
end control_unit;


architecture Behavioral of control_unit is

        signal reg_i : STD_LOGIC;
        signal reg_m : STD_LOGIC;
        
        begin
        
        
        I_OUT <= reg_i; 
        M_OUT <= reg_m;
      
        
        proc: process(CLK)
        begin
        
            if CLK'event and CLK = '1' then
               if RST = '1' then
                 reg_i <= '0';
                 reg_m <= '0';
               else
                  if LOAD_I_CLEARED = '1' then
                    reg_i <=I;
                  elsif LOAD_M_CLEARED = '1' then
                    reg_m <=M;
                end if;
             end if;
            end if;
        
        end process;      
                    
    end Behavioral;


