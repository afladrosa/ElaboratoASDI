----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 21.11.2024 12:29:19
-- Design Name: 
-- Module Name: M_enc8_4 - structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity M_enc8_4 is
    Port ( in_M : in STD_LOGIC_VECTOR (7 downto 0);
           out_M : out STD_LOGIC_VECTOR (3 downto 0));
end M_enc8_4;

architecture structural of M_enc8_4 is

    component enc4_2
        Port ( in_enc : in STD_LOGIC_VECTOR (3 downto 0);
               out_enc : out STD_LOGIC_VECTOR (1 downto 0));
    end component;

begin

    enc0 : enc4_2
        Port map(   in_enc(0) => in_M(0),
                    in_enc(1) => in_M(1),
                    in_enc(2) => in_M(2),
                    in_enc(3) => in_M(3),
                    out_enc(0) => out_M(0),
                    out_enc(1) => out_M(1)
                 );

    enc1 : enc4_2
        Port map(   in_enc(0) => in_M(4),
                    in_enc(1) => in_M(5),
                    in_enc(2) => in_M(6),
                    in_enc(3) => in_M(7),
                    out_enc(0) => out_M(2),
                    out_enc(1) => out_M(3)
                 );


end structural;
