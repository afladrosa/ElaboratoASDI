----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 28.11.2024 16:41:28
-- Design Name: 
-- Module Name: control_unit - control_unitArch
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity control_unit is
    Port ( input : in STD_LOGIC_VECTOR (3 downto 0);
           output : out STD_LOGIC_VECTOR (3 downto 0)
          );
end control_unit;

architecture control_unitArch of control_unit is

component Sistema_Compl is
    Port ( in_S : in STD_LOGIC_VECTOR (3 downto 0);
           out_S : out STD_LOGIC_VECTOR (3 downto 0));
end component; 

begin

    sis: Sistema_Compl port map(
        in_S => input,
        out_S => output
    );


end control_unitArch;
