-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 28.11.2024 15:51:05 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_control_unit is
end tb_control_unit;

architecture tb of tb_control_unit is

    component control_unit
        port (input  : in std_logic_vector (3 downto 0);
              output : out std_logic_vector (3 downto 0));
    end component;

    signal input  : std_logic_vector (3 downto 0);
    signal output : std_logic_vector (3 downto 0);

begin

    dut : control_unit
    port map (input  => input,
              output => output);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        input <= (others => '0');

        -- EDIT Add stimuli here

        wait for 100 ns;
        input <= "1111";
        
        wait for 100 ns;
        input <= "0111";
        
        wait for 100 ns;
        input <= "0010";

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_control_unit of tb_control_unit is
    for tb
    end for;
end cfg_tb_control_unit;