-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 21.11.2024 11:36:51 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_rom16_8 is
end tb_rom16_8;

architecture tb of tb_rom16_8 is

    component rom16_8
        port (in_rom  : in std_logic_vector (3 downto 0);
              out_rom : out std_logic_vector (7 downto 0));
    end component;

    signal in_rom  : std_logic_vector (3 downto 0);
    signal out_rom : std_logic_vector (7 downto 0);

begin

    dut : rom16_8
    port map (in_rom  => in_rom,
              out_rom => out_rom);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        in_rom <= (others => '0');

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_rom16_8 of tb_rom16_8 is
    for tb
    end for;
end cfg_tb_rom16_8;