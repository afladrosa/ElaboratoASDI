-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 21.11.2024 11:40:08 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_Sistema_Compl is
end tb_Sistema_Compl;

architecture tb of tb_Sistema_Compl is

    component Sistema_Compl
        port (in_S  : in std_logic_vector (3 downto 0);
              out_S : out std_logic_vector (3 downto 0));
    end component;

    signal in_S  : std_logic_vector (3 downto 0);
    signal out_S : std_logic_vector (3 downto 0);

begin

    dut : Sistema_Compl
    port map (in_S  => in_S,
              out_S => out_S);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        in_S <= (others => '0');

        -- EDIT Add stimuli here
        
        wait for 100 ns;
        in_S <= "0000";
        
        wait for 100 ns;
        in_S <= "1111";
        
        wait for 100 ns;
        in_S <= "0111";
        
        wait for 100 ns;
        in_S <= "0010";

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_Sistema_Compl of tb_Sistema_Compl is
    for tb
    end for;
end cfg_tb_Sistema_Compl;