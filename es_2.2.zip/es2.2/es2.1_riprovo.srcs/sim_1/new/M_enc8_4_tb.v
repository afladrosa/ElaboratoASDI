-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 21.11.2024 11:31:27 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_M_enc8_4 is
end tb_M_enc8_4;

architecture tb of tb_M_enc8_4 is

    component M_enc8_4
        port (in_M  : in std_logic_vector (7 downto 0);
              out_M : out std_logic_vector (3 downto 0));
    end component;

    signal in_M  : std_logic_vector (7 downto 0);
    signal out_M : std_logic_vector (3 downto 0);

begin

    dut : M_enc8_4
    port map (in_M  => in_M,
              out_M => out_M);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        in_M <= (others => '0');

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_M_enc8_4 of tb_M_enc8_4 is
    for tb
    end for;
end cfg_tb_M_enc8_4;