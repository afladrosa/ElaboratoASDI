-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 21.11.2024 11:27:45 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_enc4_2 is
end tb_enc4_2;

architecture tb of tb_enc4_2 is

    component enc4_2
        port (in_enc  : in std_logic_vector (3 downto 0);
              out_enc : out std_logic_vector (1 downto 0));
    end component;

    signal in_enc  : std_logic_vector (3 downto 0);
    signal out_enc : std_logic_vector (1 downto 0);

begin

    dut : enc4_2
    port map (in_enc  => in_enc,
              out_enc => out_enc);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        in_enc <= (others => '0');

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_enc4_2 of tb_enc4_2 is
    for tb
    end for;
end cfg_tb_enc4_2;