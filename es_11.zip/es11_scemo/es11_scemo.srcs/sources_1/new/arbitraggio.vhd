library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity arbitraggio is
    Port ( val_in_1 : in std_logic;
           val_in_2 : in std_logic;
           val_in_3 : in std_logic;
           val_in_4 : in std_logic;
           msg_1 : in std_logic_vector(1 downto 0);
           msg_2 : in std_logic_vector(1 downto 0);
           msg_3 : in std_logic_vector(1 downto 0);
           msg_4 : in std_logic_vector(1 downto 0);
           dest_1 : in std_logic_vector(1 downto 0);
           dest_2 : in std_logic_vector(1 downto 0);
           dest_3 : in std_logic_vector(1 downto 0);
           dest_4 : in std_logic_vector(1 downto 0);
           sel_out : out std_logic_vector(1 downto 0);
           msg_out : out std_logic_vector(1 downto 0);
           dest_out : out std_logic_vector(1 downto 0)
    );
end arbitraggio;

architecture Behavioral of arbitraggio is

begin

    process(val_in_1, val_in_2, val_in_3, val_in_4)
    begin
        if val_in_1 = '1' then
            sel_out <= "00";
            msg_out <= msg_1;
            dest_out <= dest_1;
            
        elsif val_in_2 = '1' then
            sel_out <= "01";
            msg_out <= msg_2;
            dest_out <= dest_2;
        
        elsif val_in_3 = '1' then
            sel_out <= "10";
            msg_out <= msg_3;
            dest_out <= dest_3;
        
        elsif val_in_4 = '1' then
            sel_out <= "11";
            msg_out <= msg_4;
            dest_out <= dest_4;
        
        else
            sel_out <= "--";
            msg_out <= "--";
            dest_out <= "--";
        end if;
    end process;

end Behavioral;
