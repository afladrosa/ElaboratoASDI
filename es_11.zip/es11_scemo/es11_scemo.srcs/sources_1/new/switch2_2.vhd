library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity switch2_2 is
  Port ( msg_1 : in std_logic_vector(1 downto 0);
         msg_2 : in std_logic_vector(1 downto 0);
         sel_m : in std_logic;
         sel_d : in std_logic;
         out_1 : out std_logic_vector(1 downto 0);
         out_2 : out std_logic_vector(1 downto 0)
        );
end switch2_2;

architecture Structural of switch2_2 is

component mux2_1 is
    Port ( c0 : in STD_LOGIC_VECTOR(1 downto 0);
           c1 : in STD_LOGIC_VECTOR(1 downto 0);
           s : in STD_LOGIC;
           y : out STD_LOGIC_VECTOR(1 downto 0));
end component mux2_1;

component demux1_2 is
    Port ( h0 : in STD_LOGIC_VECTOR(1 downto 0);
           d0 : out STD_LOGIC_VECTOR(1 downto 0);
           d1 : out STD_LOGIC_VECTOR(1 downto 0);
           s0 : in STD_LOGIC);
end component demux1_2;

signal out_mux : std_logic_vector(1 downto 0);

begin

    mux: mux2_1
    port map ( c0 => msg_1,
               c1 => msg_2,
               s => sel_m,
               y => out_mux);

    demux: demux1_2
    port map ( h0 => out_mux,
               d0 => out_1,
               d1 => out_2,
               s0 => sel_d);
               

end Structural;