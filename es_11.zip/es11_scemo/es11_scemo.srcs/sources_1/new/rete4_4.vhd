library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity rete4_4 is
    Port ( msg_1 : in std_logic_vector(1 downto 0);
           msg_2 : in std_logic_vector(1 downto 0);
           msg_3 : in std_logic_vector(1 downto 0);
           msg_4 : in std_logic_vector(1 downto 0);
           dest_1 : in std_logic_vector(1 downto 0);
           dest_2 : in std_logic_vector(1 downto 0);
           dest_3 : in std_logic_vector(1 downto 0);
           dest_4 : in std_logic_vector(1 downto 0);
           val_1 : in std_logic;
           val_2 : in std_logic;
           val_3 : in std_logic;
           val_4 : in std_logic;
           out_1 : out std_logic_vector(1 downto 0);
           out_2 : out std_logic_vector(1 downto 0);
           out_3 : out std_logic_vector(1 downto 0);
           out_4 : out std_logic_vector(1 downto 0);
           val_out : out std_logic_vector(1 downto 0)
    );
end rete4_4;

architecture Structural of rete4_4 is

component switch2_2 is
  Port ( msg_1 : in std_logic_vector(1 downto 0);
         msg_2 : in std_logic_vector(1 downto 0);
         sel_m : in std_logic;
         sel_d : in std_logic;
         out_1 : out std_logic_vector(1 downto 0);
         out_2 : out std_logic_vector(1 downto 0)
        );
end component switch2_2;

component priorita is
    Port ( val_in_1 : in std_logic;
           val_in_2 : in std_logic;
           val_in_3 : in std_logic;
           val_in_4 : in std_logic;
           msg_1 : in std_logic_vector(1 downto 0);
           msg_2 : in std_logic_vector(1 downto 0);
           msg_3 : in std_logic_vector(1 downto 0);
           msg_4 : in std_logic_vector(1 downto 0);
           dest_1 : in std_logic_vector(1 downto 0);
           dest_2 : in std_logic_vector(1 downto 0);
           dest_3 : in std_logic_vector(1 downto 0);
           dest_4 : in std_logic_vector(1 downto 0);
           sel_out : out std_logic_vector(1 downto 0);
           msg_1_out : out std_logic_vector(1 downto 0);
           msg_2_out : out std_logic_vector(1 downto 0);
           msg_3_out : out std_logic_vector(1 downto 0);
           msg_4_out : out std_logic_vector(1 downto 0);
           dest_out : out std_logic_vector(1 downto 0)
    );
end component priorita;

signal msg_1_tmp : std_logic_vector(1 downto 0);
signal msg_2_tmp : std_logic_vector(1 downto 0);
signal msg_3_tmp : std_logic_vector(1 downto 0);
signal msg_4_tmp : std_logic_vector(1 downto 0);
signal sel_m : std_logic_vector(1 downto 0);
signal sel_d : std_logic_vector(1 downto 0);
signal tmp_1 : std_logic_vector(1 downto 0);
signal tmp_2 : std_logic_vector(1 downto 0);
signal tmp_3 : std_logic_vector(1 downto 0);
signal tmp_4 : std_logic_vector(1 downto 0);

begin

    val_out <= sel_d;
                                
    prio: priorita
    port map ( val_in_1 => val_1,
               val_in_2 => val_2,
               val_in_3 => val_3,
               val_in_4 => val_4,
               msg_1 => msg_1,
               msg_2 => msg_2,
               msg_3 => msg_3,
               msg_4 => msg_4,
               dest_1 => dest_1,
               dest_2 => dest_2,
               dest_3 => dest_3,
               dest_4 => dest_4,
               sel_out => sel_m,
               msg_1_out => msg_1_tmp,
               msg_2_out => msg_2_tmp,
               msg_3_out => msg_3_tmp,
               msg_4_out => msg_4_tmp,
               dest_out => sel_d
        );

    switch1: switch2_2
    port map ( msg_1 => msg_1_tmp,
               msg_2 => msg_3_tmp,
               sel_m => sel_m(1),
               sel_d => sel_d(1),
               out_1 => tmp_1,
               out_2 => tmp_3
              );
              
    switch2: switch2_2
    port map ( msg_1 => msg_2_tmp,
               msg_2 => msg_4_tmp,
               sel_m => sel_m(1),
               sel_d => sel_d(1),
               out_1 => tmp_2,
               out_2 => tmp_4
              );
                            
    switch3: switch2_2
    port map ( msg_1 => tmp_1,
               msg_2 => tmp_2,
               sel_m => sel_m(0),
               sel_d => sel_d(0),
               out_1 => out_1,
               out_2 => out_2
              );
              
    switch4: switch2_2
    port map ( msg_1 => tmp_3,
               msg_2 => tmp_4,
               sel_m => sel_m(0),
               sel_d => sel_d(0),
               out_1 => out_3,
               out_2 => out_4
              );

end Structural;
