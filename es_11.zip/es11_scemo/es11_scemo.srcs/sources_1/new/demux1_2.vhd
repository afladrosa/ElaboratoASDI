library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity demux1_2 is
    Port ( h0 : in STD_LOGIC_VECTOR(1 downto 0);
           d0 : out STD_LOGIC_VECTOR(1 downto 0);
           d1 : out STD_LOGIC_VECTOR(1 downto 0);
           s0 : in STD_LOGIC);
end demux1_2;

architecture Behavioral of demux1_2 is

begin
    d0 <= h0 when s0 = '0' else
          "--";
    d1 <= h0 when s0 = '1' else
          "--";
        
end Behavioral;