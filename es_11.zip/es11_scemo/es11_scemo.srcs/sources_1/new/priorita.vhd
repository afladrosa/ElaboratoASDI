library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity priorita is
    Port ( val_in_1 : in std_logic;
           val_in_2 : in std_logic;
           val_in_3 : in std_logic;
           val_in_4 : in std_logic;
           msg_1 : in std_logic_vector(1 downto 0);
           msg_2 : in std_logic_vector(1 downto 0);
           msg_3 : in std_logic_vector(1 downto 0);
           msg_4 : in std_logic_vector(1 downto 0);
           dest_1 : in std_logic_vector(1 downto 0);
           dest_2 : in std_logic_vector(1 downto 0);
           dest_3 : in std_logic_vector(1 downto 0);
           dest_4 : in std_logic_vector(1 downto 0);
           sel_out : out std_logic_vector(1 downto 0);
           msg_1_out : out std_logic_vector(1 downto 0);
           msg_2_out : out std_logic_vector(1 downto 0);
           msg_3_out : out std_logic_vector(1 downto 0);
           msg_4_out : out std_logic_vector(1 downto 0);
           dest_out : out std_logic_vector(1 downto 0)
    );
end priorita;

architecture Structural of priorita is

component arbitraggio is
    Port ( val_in_1 : in std_logic;
           val_in_2 : in std_logic;
           val_in_3 : in std_logic;
           val_in_4 : in std_logic;
           msg_1 : in std_logic_vector(1 downto 0);
           msg_2 : in std_logic_vector(1 downto 0);
           msg_3 : in std_logic_vector(1 downto 0);
           msg_4 : in std_logic_vector(1 downto 0);
           dest_1 : in std_logic_vector(1 downto 0);
           dest_2 : in std_logic_vector(1 downto 0);
           dest_3 : in std_logic_vector(1 downto 0);
           dest_4 : in std_logic_vector(1 downto 0);
           sel_out : out std_logic_vector(1 downto 0);
           msg_out : out std_logic_vector(1 downto 0);
           dest_out : out std_logic_vector(1 downto 0)
    );
end component arbitraggio;

component demux1_4 is
    Port ( m : in STD_LOGIC_VECTOR(1 downto 0);
           n0 : out STD_LOGIC_VECTOR(1 downto 0);
           n1 : out STD_LOGIC_VECTOR(1 downto 0);
           n2 : out STD_LOGIC_VECTOR(1 downto 0);
           n3 : out STD_LOGIC_VECTOR(1 downto 0);
           t0 : in STD_LOGIC;
           t1 : in STD_LOGIC);
end component demux1_4;

signal msg : std_logic_vector(1 downto 0);
signal sel : std_logic_vector(1 downto 0);

begin

    sel_out <= sel;

    arb: arbitraggio
    port map ( val_in_1 => val_in_1,
               val_in_2 => val_in_2,
               val_in_3 => val_in_3,
               val_in_4 => val_in_4,
               msg_1 => msg_1,
               msg_2 => msg_2,
               msg_3 => msg_3,
               msg_4 => msg_4,
               dest_1 => dest_1,
               dest_2 => dest_2,
               dest_3 => dest_3,
               dest_4 => dest_4,
               sel_out => sel,
               msg_out => msg,
               dest_out => dest_out
        );

    demux: demux1_4
    port map ( m => msg,
               n0 => msg_1_out,
               n1 => msg_2_out,
               n2 => msg_3_out,
               n3 => msg_4_out,
               t0 => sel(1),
               t1 => sel(0));

end Structural;
