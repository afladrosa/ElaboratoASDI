library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux2_1 is
    Port ( c0 : in STD_LOGIC_VECTOR(1 downto 0);
           c1 : in STD_LOGIC_VECTOR(1 downto 0);
           s : in STD_LOGIC;
           y : out STD_LOGIC_VECTOR(1 downto 0));
end mux2_1;

architecture Behavioral of mux2_1 is

begin

    y <= c0 when s = '0' else
         c1 when s = '1' else
         "--";

end Behavioral;