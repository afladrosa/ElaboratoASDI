-- DEMUX 1:4 -> structural

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity demux1_4 is
    Port ( m : in STD_LOGIC_VECTOR(1 downto 0);
           n0 : out STD_LOGIC_VECTOR(1 downto 0);
           n1 : out STD_LOGIC_VECTOR(1 downto 0);
           n2 : out STD_LOGIC_VECTOR(1 downto 0);
           n3 : out STD_LOGIC_VECTOR(1 downto 0);
           t0 : in STD_LOGIC;
           t1 : in STD_LOGIC);
end demux1_4;

architecture Structural of demux1_4 is

    signal v0 : STD_LOGIC_VECTOR(1 downto 0) := "00";
    signal v1 : STD_LOGIC_VECTOR(1 downto 0) := "00";
    
    component demux1_2
         Port ( h0 : in STD_LOGIC_VECTOR(1 downto 0);
                d0 : out STD_LOGIC_VECTOR(1 downto 0);
                d1 : out STD_LOGIC_VECTOR(1 downto 0);
                s0 : in STD_LOGIC);
    end component;

begin

    demux0: demux1_2
    Port map(   h0 => m,
                d0 => v0,
                d1 => v1,
                s0 => t0);
		                
    demux1: demux1_2
    Port map(   h0 => v0,
                d0 => n0,
                d1 => n1,
                s0 => t1);
                
    demux2: demux1_2
    Port map(   h0 => v1,
                d0 => n2,
                d1 => n3,
                s0 => t1);


end Structural;