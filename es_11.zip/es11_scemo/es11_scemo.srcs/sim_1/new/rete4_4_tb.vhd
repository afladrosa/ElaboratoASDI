-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : Tue, 27 May 2025 08:32:30 GMT
-- Request id : cfwk-fed377c2-6835789ea5d3e

library ieee;
use ieee.std_logic_1164.all;

entity tb_rete4_4 is
end tb_rete4_4;

architecture tb of tb_rete4_4 is

    component rete4_4
        port (msg_1   : in std_logic_vector (1 downto 0);
              msg_2   : in std_logic_vector (1 downto 0);
              msg_3   : in std_logic_vector (1 downto 0);
              msg_4   : in std_logic_vector (1 downto 0);
              dest_1  : in std_logic_vector (1 downto 0);
              dest_2  : in std_logic_vector (1 downto 0);
              dest_3  : in std_logic_vector (1 downto 0);
              dest_4  : in std_logic_vector (1 downto 0);
              val_1   : in std_logic;
              val_2   : in std_logic;
              val_3   : in std_logic;
              val_4   : in std_logic;
              out_1   : out std_logic_vector (1 downto 0);
              out_2   : out std_logic_vector (1 downto 0);
              out_3   : out std_logic_vector (1 downto 0);
              out_4   : out std_logic_vector (1 downto 0);
              val_out : out std_logic_vector (1 downto 0));
    end component;

    signal msg_1   : std_logic_vector (1 downto 0);
    signal msg_2   : std_logic_vector (1 downto 0);
    signal msg_3   : std_logic_vector (1 downto 0);
    signal msg_4   : std_logic_vector (1 downto 0);
    signal dest_1  : std_logic_vector (1 downto 0);
    signal dest_2  : std_logic_vector (1 downto 0);
    signal dest_3  : std_logic_vector (1 downto 0);
    signal dest_4  : std_logic_vector (1 downto 0);
    signal val_1   : std_logic;
    signal val_2   : std_logic;
    signal val_3   : std_logic;
    signal val_4   : std_logic;
    signal out_1   : std_logic_vector (1 downto 0);
    signal out_2   : std_logic_vector (1 downto 0);
    signal out_3   : std_logic_vector (1 downto 0);
    signal out_4   : std_logic_vector (1 downto 0);
    signal val_out : std_logic_vector (1 downto 0);

begin

    dut : rete4_4
    port map (msg_1   => msg_1,
              msg_2   => msg_2,
              msg_3   => msg_3,
              msg_4   => msg_4,
              dest_1  => dest_1,
              dest_2  => dest_2,
              dest_3  => dest_3,
              dest_4  => dest_4,
              val_1   => val_1,
              val_2   => val_2,
              val_3   => val_3,
              val_4   => val_4,
              out_1   => out_1,
              out_2   => out_2,
              out_3   => out_3,
              out_4   => out_4,
              val_out => val_out);

    stimuli : process
    begin
        -- ***EDIT*** Adapt initialization as needed
        msg_1 <= (others => '0');
        msg_2 <= (others => '0');
        msg_3 <= (others => '0');
        msg_4 <= (others => '0');
        dest_1 <= (others => '0');
        dest_2 <= (others => '0');
        dest_3 <= (others => '0');
        dest_4 <= (others => '0');
        val_1 <= '0';
        val_2 <= '0';
        val_3 <= '0';
        val_4 <= '0';

        -- ***EDIT*** Add stimuli here
        wait for 10 ns;
        msg_1 <= "11";
        dest_1 <= "00";
        msg_2 <= "10";
        dest_2 <= "11";
        
        wait for 10 ns;
        val_1 <= '1';
        val_2 <= '1';
        
        wait for 40 ns;
        val_1 <= '0';
        val_2 <= '0';
        
        wait for 40 ns;
        msg_3 <= "01";
        dest_3 <= "10";
        val_3 <= '1';
        msg_4 <= "11";
        dest_4 <= "11";
        val_4 <= '1';

        wait for 40 ns;
        val_3 <= '0';
        val_4 <= '0';
        
        wait for 40 ns;
        msg_4 <= "00";
        dest_4 <= "00";
        val_4 <= '1';

        wait for 40 ns;
        val_4 <= '0';
        
        wait for 40 ns;
        msg_1 <= "01";
        dest_1 <= "10";
        val_1 <= '1';
        msg_3 <= "11";
        dest_3 <= "11";
        val_3 <= '1';

        wait for 40 ns;
        val_1 <= '0';
        val_3 <= '0';
        
        wait for 40 ns;
        msg_1 <= "00";
        dest_1 <= "11";
        val_1 <= '1';
        msg_2 <= "01";
        dest_2 <= "10";
        val_2 <= '1';
        msg_3 <= "10";
        dest_3 <= "01";
        val_3 <= '1';
        msg_4 <= "11";
        dest_4 <= "00";
        val_4 <= '1';

        wait for 40 ns;
        val_1 <= '0';
        val_2 <= '0';
        val_3 <= '0';
        val_4 <= '0';

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_rete4_4 of tb_rete4_4 is
    for tb
    end for;
end cfg_tb_rete4_4;