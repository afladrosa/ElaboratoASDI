library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity sistema_complessivo is
  Port ( 
        stop: in std_logic;
        visualizza: in std_logic; 
        locazione_lettura: out std_logic_vector(3 downto 0);
        clock: in std_logic;
        reset: in std_logic;
        set: in std_logic;
        minutes_in: in std_logic_vector(5 downto 0);
        seconds_in: in std_logic_vector(5 downto 0);
        hours_in: in std_logic_vector(4 downto 0);
        seconds_out: out std_logic_vector(5 downto 0);
        minutes_out: out std_logic_vector(5 downto 0);
        hours_out: out std_logic_vector(4 downto 0);
        -- uscita dalla memoria
        mem_seconds_out: out std_logic_vector(5 downto 0);
        mem_minutes_out: out std_logic_vector(5 downto 0);
        mem_hours_out: out std_logic_vector(4 downto 0);
        
        en_read: in std_logic
        
        );
		
end sistema_complessivo;

architecture Structural of sistema_complessivo is
          
          signal en_write: std_logic; -- segnale in uscita dal gestore della memoria che dice alla memoria quando scrivere
          signal addr_temp: std_logic_vector(3 downto 0); -- indirizzo in uscita dal contatore che indica l'indirizzo di memoria in cui scrivere
          signal addr_temp_lettura: std_logic_vector(3 downto 0); -- indirizzo in uscita dal secondo contatore che indica l'indirizzo di memoria da cui leggere 
          signal output_timer: std_logic_vector(16 downto 0); 
          constant N_locazioni: integer := 16;
          constant N_bit: integer := 4;
          signal umax: std_logic; 
          signal output_mem: std_logic_vector(16 downto 0);
          signal en_count_scrittura: std_logic; --abilitazione del contatore, in uscita da gestore memoria
          signal en_count_lettura: std_logic; --abilitazione del contatore per la lettura. L'abilitazione � visualizza, l'uscita del gestore gestione_visualizza

          

        
          component cronometro is 
            Port ( 
                clock: in std_logic;
                reset: in std_logic;
                set: in std_logic;
                minutes_in: in std_logic_vector(5 downto 0);
                seconds_in: in std_logic_vector(5 downto 0);
                hours_in: in std_logic_vector(4 downto 0);
                
                seconds_out: out std_logic_vector(5 downto 0);
                minutes_out: out std_logic_vector(5 downto 0);
                hours_out: out std_logic_vector(4 downto 0)
                 
            );
        end component;
          

            
           component mem is
            port(
                CLK: in std_logic;
                RST: in std_logic;
                write: in std_logic; -- Segnale di scrittura
                read: in std_logic; -- segnale di lettura
                ADDR : in std_logic_vector(3 downto 0);
                ADDR_lettura: in std_logic_vector(3 downto 0);
                data_in: in std_logic_vector(16 downto 0);
                data_out: out std_logic_vector(16 downto 0)
            );
        end component;

        
        
        component counter_locazioni is
        generic(
            
            n: integer := N_bit ;--numero di bit necessari
            modulo: integer := N_locazioni
            
            );
        
        Port ( clock : in  STD_LOGIC;
               reset : in  STD_LOGIC; --ingresso di reset per azzerare il contatore
               enable : in STD_LOGIC; 
               umax: out STD_LOGIC; -- si alza quando si raggiunge il valore massimo di conteggio
               counter : out  STD_LOGIC_VECTOR (N_bit-1 downto 0));
                             
    end component;
    
    
    
    component gestore_mem is
      Port (
            stop: in std_logic;
            clock: in std_logic;
            reset: in std_logic;
            write: out std_logic;
            en_count: out std_logic;
            count: STD_LOGIC_VECTOR (N_bit-1 downto 0) 
         );
    end component;

begin
            
          
                   
          cronometro0: cronometro
          Port map ( 
                clock=>clock,
                reset=> reset,
                set=> set,
                minutes_in => minutes_in,
                seconds_in=> seconds_in,
                hours_in=> hours_in,
                
                seconds_out=>output_timer(5 downto 0),
                minutes_out=> output_timer(11 downto 6),
                hours_out => output_timer(16 downto 12)
            
           );
           
            seconds_out<=output_timer(5 downto 0);
            minutes_out<= output_timer(11 downto 6);
            hours_out <= output_timer(16 downto 12);
            
            
           mem0: mem
            port map(
                CLK => clock,
                RST => reset,
                write => en_write,
                read =>en_read,
                ADDR => addr_temp,
                ADDR_lettura => addr_temp_lettura,
                data_in => output_timer, -- INGRESSO CHE SCRIVO SOLO QUANDO MI ARRIVA IL SEGNALE DI WRITE 
                data_out => output_mem
            );
            
            
            mem_seconds_out<=output_mem(5 downto 0);
            mem_minutes_out<= output_mem(11 downto 6);
            mem_hours_out <= output_mem(16 downto 12);
            
            
           
            
        cont_locazioni_scrittura: counter_locazioni
        generic map(
            
            n => N_bit ,--numero di bit necessari
            modulo=>  N_locazioni
            
            )
        
        Port map
              ( clock=> clock,
               reset=> reset, --ingresso di reset per azzerare il contatore
               enable=> en_count_scrittura,  
               umax=>  umax, -- si alza quando si raggiunge il valore massimo di conteggio
               counter => addr_temp
               );
               
        cont_locazioni_lettura: counter_locazioni
        generic map(
            
            n => N_bit ,--numero di bit necessari
            modulo=>  N_locazioni
            
            )
        
        Port map
              ( clock=> clock,
               reset=> reset, --ingresso di reset per azzerare il contatore
               enable=> visualizza,  
               umax=>  umax, -- si alza quando si raggiunge il valore massimo di conteggio
               counter => addr_temp_lettura
               );
               
               
       gestore_mem0: gestore_mem
        port map(
            stop => stop,
            reset=> reset,
            clock=> clock,
            write=>en_write, 
            en_count=> en_count_scrittura,
            count=>addr_temp
        );


        locazione_lettura<=addr_temp_lettura;

            
end Structural;
