library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity mem is
    port(
        CLK: in std_logic;
        RST: in std_logic;
        write: in std_logic; -- Segnale di scrittura
        read: in std_logic;  -- Segnale di lettura

        ADDR : in std_logic_vector(3 downto 0);
        ADDR_lettura: in std_logic_vector(3 downto 0);
        data_in: in std_logic_vector(16 downto 0);
        data_out: out std_logic_vector(16 downto 0)
    );
end mem;

architecture Behavioral of mem is
    type mem_type is array (0 to 15) of std_logic_vector(16 downto 0);
    signal MEM : mem_type := (others => (others => '0')); -- Inizializza tutta la memoria a 0
    signal data_reg : std_logic_vector(16 downto 0);
    
begin


    process(CLK)
    begin
        if rising_edge(CLK) then
            if RST = '1' then  -- Reset sincrono: azzera tutta la memoria
                for i in 0 to 15 loop
                    MEM(i) <= (others => '0');
                end loop;
            elsif write = '1' then  -- Scrittura sincrona
                MEM(to_integer(unsigned(ADDR))) <= data_in;
            end if;
            if read = '1' then
                    data_reg <= MEM(to_integer(unsigned(ADDR_lettura)));
                end if;
        end if;
    end process;
    

    data_out <= data_reg;

end Behavioral;