

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity gestione_visualizza is
  Port (
    clock : in std_logic;
    reset : in std_logic;
    visualizza_btn : in std_logic;
    en_count: out std_logic; -- abilita il contatore degli indirizzi di memoria in lettura
    read: out std_logic;
    visualizza_mode : out std_logic;
    count: in std_logic_vector(3 downto 0)
  );
end gestione_visualizza;

architecture Behavioral of gestione_visualizza is
 signal mode : std_logic := '0';
 
     type state is (idle, leggi, fine);


signal current_state,next_state: state;

	begin 

		
	reg_stato: process(clock)
			  begin
			  if(clock'event and clock='1') then
		         if(reset='1') then 
				    current_state <=idle;
			    else 
				    current_state <=next_state;
			     end if;
			  end if;
			  end process;
			  
			  
    comb: process(current_state,visualizza_btn)
		  begin
		  
		  	            
	     CASE current_state is
		  
		  WHEN idle => 
		      read<='0';
		      en_count<='0';
		      if visualizza_btn = '1' then
        			next_state<=leggi;
	
        	   else
        	       next_state<=idle;
        	    end if;
		          
		  WHEN leggi =>
		      read<='1';
		      en_count<='1';
		      if count="1111" then
		          next_state<=fine;
		      else 
		          next_state<=idle;
               end if;
		      			

        when fine =>
              read <='0';
		      en_count<='0';
                
		
		end CASE;
	end process;


  visualizza_mode <= mode;
  



 -- Il segnale 'mode' viene aggiornato in un processo sincrono
-- per garantire che rimanga attivo (a '1') durante l'intera
-- fase di visualizzazione, fino a disattivazione esplicita (reset).
-- Questa scelta implica l'uso di un registro per memorizzare l'output.

  process(clock)
  begin
    if rising_edge(clock) then
      if reset = '1' then
        mode <= '0';
      elsif current_state = leggi then
        mode <= '1';
     -- elsif current_state = fine then
       -- mode <= '0';
      end if;
    end if;
  end process;



end Behavioral;
