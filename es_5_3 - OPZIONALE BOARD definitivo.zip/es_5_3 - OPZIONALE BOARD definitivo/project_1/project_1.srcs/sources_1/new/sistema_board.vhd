library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity sistema_on_board is
  Port ( 
        clock: in std_logic;
        stop: in std_logic; -- bottone M17
        visualizza: in std_logic; -- bottone P18
        reset: in std_logic; -- bottone N17
        set_btn: in std_logic; -- bottone M18
        SW: in std_logic_vector(5 downto 0);
        load: in std_logic; -- bottone P17 
        anodes : out  STD_LOGIC_VECTOR (7 downto 0); --anodi e catodi delle cifre, sono un output del topmodule
		cathodes : out  STD_LOGIC_VECTOR (7 downto 0)
     
    
   );
end sistema_on_board;

architecture Structural of sistema_on_board is

        signal value_temp : std_logic_vector(16 downto 0);
        signal value_temp_mem : std_logic_vector(16 downto 0);
        
        signal value_to_encode: std_logic_vector(16 downto 0);
        signal value_encoded : std_logic_vector(31 downto 0);
        
        signal cleared_load: std_logic;
        signal sec_set: std_logic_vector(5 downto 0);
        signal min_set: std_logic_vector(5 downto 0);
        signal h_set: std_logic_vector(4 downto 0);
        
         signal stop_cleared: std_logic;
         signal visualizza_cleared: std_logic;
         signal locazione_lettura: std_logic_vector(3 downto 0);
         
         
       signal visualizza_mode : std_logic := '0';
       
       signal en_count_lettura: std_logic :='0';
       signal en_read: std_logic :='0';
       
       



        component sistema_complessivo is
          Port ( 
                stop: in std_logic;
                visualizza: in std_logic; 
                locazione_lettura: out std_logic_vector(3 downto 0);
                clock: in std_logic;
                reset: in std_logic;
                set: in std_logic;
                minutes_in: in std_logic_vector(5 downto 0);
                seconds_in: in std_logic_vector(5 downto 0);
                hours_in: in std_logic_vector(4 downto 0);
                seconds_out: out std_logic_vector(5 downto 0);
                minutes_out: out std_logic_vector(5 downto 0);
                hours_out: out std_logic_vector(4 downto 0);
                mem_seconds_out: out std_logic_vector(5 downto 0);
                mem_minutes_out: out std_logic_vector(5 downto 0);
                mem_hours_out: out std_logic_vector(4 downto 0);
                en_read: in std_logic
                );
                
        end component;
        
        component ButtonDebouncer is
        generic (                       
            CLK_period: integer := 10;  -- periodo del clock (della board) in nanosecondi
            btn_noise_time: integer := 10000000 -- durata stimata dell'oscillazione del bottone in nanosecondi
                                                -- il valore di default � 10 millisecondi
        );
        Port ( RST : in STD_LOGIC;
               CLK : in STD_LOGIC;
               BTN : in STD_LOGIC;
               CLEARED_BTN : out STD_LOGIC);
        end component;

        
        component display_seven_segments is
        Generic( 
                    clock_frequency_in : integer := 50000000; 
                    clock_frequency_out : integer := 5000000
                    );
        Port ( clock : in  STD_LOGIC;
               reset : in  STD_LOGIC;
               value32_in : in  STD_LOGIC_VECTOR (31 downto 0);
               enable : in  STD_LOGIC_VECTOR (7 downto 0);
               dots : in  STD_LOGIC_VECTOR (7 downto 0);
               anodes : out  STD_LOGIC_VECTOR (7 downto 0);
               cathodes : out  STD_LOGIC_VECTOR (7 downto 0));
        end component;
        
        
        component control_unit is -- gestisce l'acquisizione del tempo settato
        Port ( 
		   clock : in  STD_LOGIC;
           reset : in  STD_LOGIC;
		   load : in  STD_LOGIC;
		   seconds_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i secondi
		   minutes_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i minuti
		   hours_in : in STD_LOGIC_VECTOR(4 downto 0); --valore acquisito da 6 switch per le ore
           
           seconds_out: out STD_LOGIC_VECTOR(5 downto 0); --valori da mostrare in decimale sul display
		   minutes_out : out STD_LOGIC_VECTOR(5 downto 0); 
		   hours_out : out STD_LOGIC_VECTOR(4 downto 0)
			  );
        end component;
        
        component encoder is
        Port(
               in_sec: in std_logic_vector(5 downto 0); 
               in_min: in std_logic_vector(5 downto 0); 
               in_ore: in std_logic_vector(4 downto 0); 
               value32_out: out  STD_LOGIC_VECTOR (31 downto 0)
            
            );
         end component;
         
         
        component mux_2_1 is
            Port ( sec0    : in  STD_LOGIC_VECTOR(5 downto 0);
                   min0    : in  STD_LOGIC_VECTOR(5 downto 0);
                   h0      : in  STD_LOGIC_VECTOR(4 downto 0);
                   sec1    : in  STD_LOGIC_VECTOR(5 downto 0);
                   min1    : in  STD_LOGIC_VECTOR(5 downto 0);
                   h1      : in  STD_LOGIC_VECTOR(4 downto 0);
                   s       : in  STD_LOGIC;
                   sec_out : out STD_LOGIC_VECTOR(5 downto 0);
                   min_out : out STD_LOGIC_VECTOR(5 downto 0);
                   h_out   : out STD_LOGIC_VECTOR(4 downto 0)
                 );
            end component;
            
            
         component gestione_visualizza is
          Port (
            clock : in std_logic;
            reset : in std_logic;
            visualizza_btn : in std_logic;
            en_count: out std_logic; -- abilita il contatore degli indirizzi di memoria in lettura
            read: out std_logic;
            visualizza_mode : out std_logic;
            count: in std_logic_vector(3 downto 0)
          );
        end component;

                
begin
    

    sistema_complessivo0: sistema_complessivo 
      Port map ( 
            stop => stop_cleared,
            visualizza=> en_count_lettura, 
            locazione_lettura =>locazione_lettura,
            clock => clock,
            reset=> reset,
            set=> set_btn,
            minutes_in => min_set,
            seconds_in => sec_set,
            hours_in=> h_set,
            seconds_out => value_temp(5 downto 0),
            minutes_out =>value_temp(11 downto 6),
            hours_out => value_temp(16 downto 12),
            mem_seconds_out => value_temp_mem(5 downto 0),
            mem_minutes_out =>value_temp_mem(11 downto 6),
            mem_hours_out => value_temp_mem(16 downto 12),
            en_read=>en_read
            );
            
        
      CU: control_unit
        Port map( 
               clock => clock,
               reset => reset,
               load => cleared_load,
               seconds_in => SW, --valore acquisito da 6 switch per i secondi
               minutes_in => SW, --valore acquisito da 6 switch per i minuti
               hours_in => SW(4 downto 0), --valore acquisito da 6 switch per le ore
               seconds_out => sec_set,
               minutes_out => min_set,
               hours_out => h_set
               
               );

         seven_segment_array: display_seven_segments GENERIC MAP(
            clock_frequency_in => 100000000, --qui inserisco i parametri effettivi (clock della board e clock in uscita desiderato)
            clock_frequency_out => 500 --inserendo un valore inferiore si vedranno le cifre illuminarsi in sequenza
            )
            PORT MAP(
                clock => clock,
                reset => reset,
                value32_in => value_encoded,
                enable => "00111111", --stabilisco che tutti i display siano accesi 
                dots =>"00010100", 
                anodes => anodes,
                cathodes => cathodes
        );
        
        bd_load: ButtonDebouncer
            generic map (                       
                CLK_period => 10,  -- periodo del clock (della board) in nanosecondi
                btn_noise_time => 10000000 -- durata stimata dell'oscillazione del bottone in nanosecondi
                                                    -- il valore di default � 10 millisecondi
            )
            Port map ( RST => reset,
                   CLK => clock,
                   BTN => load,
                   CLEARED_BTN => cleared_load
             );
            
        bd_stop: ButtonDebouncer
           generic map(
                 CLK_period => 10,  
                 btn_noise_time=> 10000000
                )
           port map(
                   RST => reset,
                   CLK => clock,
                   BTN => stop,
                   CLEARED_BTN => stop_cleared
                   );
    
           bd_visualizza: ButtonDebouncer
           generic map(
                 CLK_period => 10,  -- periodo del clock (della board) in nanosecondi
                 btn_noise_time=> 10000000
                )
           port map(
                   RST => reset,
                   CLK => clock,
                   BTN => visualizza,
                   CLEARED_BTN => visualizza_cleared
                   );
            
        encoder_display: encoder
        Port map(
               in_sec => value_to_encode(5 downto 0), 
               in_min => value_to_encode(11 downto 6),
               in_ore => value_to_encode(16 downto 12),
               value32_out => value_encoded
            );
            
                mux: mux_2_1 
            Port map( 
                sec0  => value_temp(5 downto 0),
                min0  => value_temp(11 downto 6),
                h0    => value_temp(16 downto 12),
                sec1  => value_temp_mem(5 downto 0),
                min1  => value_temp_mem(11 downto 6),
                h1    => value_temp_mem(16 downto 12),
                s     => visualizza_mode,  -- usa il segnale latched
                sec_out => value_to_encode(5 downto 0),
                min_out => value_to_encode(11 downto 6),
                h_out   => value_to_encode(16 downto 12)
            );

       
--        process(clock, reset)
--        begin
--            if reset = '1' then
--                visualizza_mode <= '0';
--            elsif rising_edge(clock) then
--                if visualizza_cleared = '1' then
--                    visualizza_mode <= '1';
--                end if;
--            end if;
--        end process;

        gestionevisualizza: gestione_visualizza
          port map (
            clock => clock,
            reset => reset,
            visualizza_btn => visualizza_cleared,
            visualizza_mode => visualizza_mode,
            count => locazione_lettura,
            en_count=> en_count_lettura,
            read => en_read
            
          );


end Structural;


