library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux_2_1 is
    Port ( sec0    : in  STD_LOGIC_VECTOR(5 downto 0);
           min0    : in  STD_LOGIC_VECTOR(5 downto 0);
           h0      : in  STD_LOGIC_VECTOR(4 downto 0);
           sec1    : in  STD_LOGIC_VECTOR(5 downto 0);
           min1    : in  STD_LOGIC_VECTOR(5 downto 0);
           h1      : in  STD_LOGIC_VECTOR(4 downto 0);
           s       : in  STD_LOGIC;
           sec_out : out STD_LOGIC_VECTOR(5 downto 0);
           min_out : out STD_LOGIC_VECTOR(5 downto 0);
           h_out   : out STD_LOGIC_VECTOR(4 downto 0)
         );
end mux_2_1;

architecture Behavioral of mux_2_1 is
begin

    sec_out <= sec0 when s = '0' else sec1;
    
    min_out <= min0 when s = '0' else min1;

    h_out <= h0 when s = '0' else h1;
    
end Behavioral;
