library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity flipflop is
    Port (
        CLK : in STD_LOGIC;       -- Segnale di clock
        RST : in STD_LOGIC;       -- Segnale di reset sincrono
        d   : in STD_LOGIC;       -- Ingresso D
        y   : out STD_LOGIC       -- Uscita Q
    );
end flipflop;

architecture Behavioral of flipflop is
begin
    process(CLK)
    begin
        if rising_edge(CLK) then    
            if RST = '1' then       
                y <= '0';           
            else
                y <= d;             
            end if;
        end if;
    end process;
end Behavioral;
