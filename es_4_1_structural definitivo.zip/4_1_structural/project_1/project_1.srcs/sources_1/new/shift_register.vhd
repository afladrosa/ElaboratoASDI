library ieee;
use ieee.std_logic_1164.all;

				
entity shift_register is
    generic(
        N: integer :=8 -- valore di default = 4
        );
    port(CLK, RST: in std_logic;
         Ei : in std_logic; --ingresso seriale esterno da sinistra (per lo shift a destra)
         Eo : in std_logic; --ingresso seriale esterno da destra (per lo shift a sinistra)
         SEL : in std_logic_vector(1 downto 0); -- selezione di direzione e numero di posizioni dello shift
                                                -- S= 00 -> shift a destra di una posizione
                                                -- S= 01 -> shift a destra di due posizioni
                                                -- S= 10 -> shift a sinistra di una posizione
                                                -- S= 11 -> shift a sinistra di due posizioni
         SO : out std_logic);
end shift_register;


architecture Structural of shift_register is
    
     signal output_ff: std_logic_vector(N-1 downto 0); -- uscita di ciascun flip flop
     signal input_ff: std_logic_vector(N-1 downto 0); --ingresso di ciascun flip flop
    
     
    
    component mux_4_1 is 
	port(	b0 : in STD_LOGIC;
			b1 : in STD_LOGIC;
			b2 : in STD_LOGIC;
			b3 : in STD_LOGIC;
			s0 : in STD_LOGIC;
			s1 : in STD_LOGIC;
			y0 : out STD_LOGIC
		);	
	end component;
	
	component flipflop
        port(
                CLK, RST, d: in std_logic;
                y: out std_logic
        );
     end component;
	
BEGIN

    MUX0: mux_4_1 port map(
        b0 => Ei,
        b1 => Ei,
        b2 => output_ff(1),
        b3 => output_ff(2),
        s0 => SEL(0),
        s1 => SEL(1),
        y0 => input_ff(0)
    );
    
    MUX1: mux_4_1 port map(
        b0 => output_ff(0),
        b1 => Ei,
        b2 => output_ff(2),
        b3 => output_ff(3),
        s0 => SEL(0),
        s1 => SEL(1),
        y0 => input_ff(1)
    );
    
    MUX_second_last: mux_4_1 port map( --penultimo
        b0 => output_ff(N-3),
        b1 => output_ff(N-4),
        b2 => output_ff(N-1),
        b3 => Eo,
        s0 => SEL(0),
        s1 => SEL(1),
        y0 => input_ff(N-2)
    );
    
    
    MUX_last: mux_4_1 port map(
        b0 => output_ff(N-2),
        b1 => output_ff(N-3),
        b2 => Eo,
        b3 => Eo,
        s0 => SEL(0),
        s1 => SEL(1),
        y0 => input_ff(N-1)
    );
    
   
	GEN_MUX: for i in 2 to N-3 generate
        MUX_INST: mux_4_1 port map (
            b0 => output_ff(i-1),
            b1 => output_ff(i-2),
            b2 => output_ff(i+1),
            b3 => output_ff(i+2),      
            s0 => SEL(0),
            s1 => SEL(1),
            y0 => input_ff(i)
        );
    end generate GEN_MUX;
    
    
    
   
    GEN_FF: for i in 0 to N-1 generate
        FF_INST: flipflop port map (
            CLK => CLK,
            RST => RST,
            d => input_ff(i),
            y => output_ff(i)
        );
    end generate GEN_FF;
    
--    FF_last: flipflop port map (
--            CLK => CLK,
--            RST => RST,
--            d => input_ff(N-1),
            
--            y => output_ff(N-1)
--        );
    
    SO <= output_ff(N-1);

    
    
END Structural;


