library ieee;
use ieee.std_logic_1164.all;

entity shift_register_tb is
end shift_register_tb;

architecture tb of shift_register_tb is

    component shift_register is
    generic(
        N: integer :=8 -- valore di default = 8
        );
    port(CLK, RST: in std_logic;
         Ei : in std_logic; --ingresso seriale esterno da sinistra (per lo shift a destra)
         Eo : in std_logic; --ingresso seriale esterno da destra (per lo shift a sinistra)
         SEL : in std_logic_vector(1 downto 0); -- selezione di direzione e numero di posizioni dello shift
                                                -- S= 00 -> shift a destra di una posizione
                                                -- S= 01 -> shift a destra di due posizioni
                                                -- S= 10 -> shift a sinistra di una posizione
                                                -- S= 11 -> shift a destra di due posizioni
         SO : out std_logic);
    end component;

    signal clk_tb : std_logic;
    signal output  : std_logic;
    signal rst : std_logic;
    signal ei : std_logic :='0';
    signal eo : std_logic:= '0';
    signal sel : std_logic_vector(1 downto 0);

    constant clk_period : time := 20 ns; 
    

begin
    -- Clock generation
   clk_process : process
   begin
		clk_tb <= '0';
		wait for clk_period/2;
		clk_tb <= '1';
		wait for clk_period/2;
   end process;
   
   
   
    uut : shift_register
    port map (CLK => clk_tb,
              RST => rst,
              Ei  => Ei,
              Eo => Eo,
              SEL => sel,
              SO  => output);
              

    stimuli : process
    begin
        
        rst <= '1';
        wait for 100ns;  --global reset
       
        rst <='0';
        sel(0) <= '0';
        sel(1) <= '0';
        Ei <= '1';
        wait for 20ns;
        Ei <= '0';
        wait for 20ns;
        Ei <= '1';
        wait for 100ns;
        Ei <= '0';
        wait for 100ns;
        Ei <= '1';
        wait for 100ns;
        sel(0)<='1';
        Ei <= '0';
        wait for 100ns;
        Ei <= '1';
        wait for 100ns;
        Ei <= '0';
        wait for 100ns;
        sel(0)<='0';
        sel(1)<='1';
        Eo<='1';
        wait for 100ns;
        Eo <= '0';
        
        wait for 100ns;
        sel(0)<='1';
        sel(1)<='1';
        Eo<='1';
        wait for 20ns;
        Eo<='0';
        wait for 100ns;
        
        -- EDIT Add stimuli here
        --wait for 100 * TbPeriod;

        -- Stop the clock and hence terminate the simulation
       -- TbSimEnded <= '1';
        wait;
    end process;

end tb;
