----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 18.11.2024 17:19:09
-- Design Name: 
-- Module Name: mux_4_1 - structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux4_1 is
    Port ( b0 : in STD_LOGIC;
           b1 : in STD_LOGIC;
           b2 : in STD_LOGIC;
           b3 : in STD_LOGIC;
           s0 : in STD_LOGIC;
           s1 : in STD_LOGIC;
           y0 : out STD_LOGIC);
end mux4_1;

architecture structural of mux4_1 is

    signal v0 : STD_LOGIC := '0';
    signal v1 : STD_LOGIC := '0';
    
    component mux2_1
        port(  c0 : in STD_LOGIC;
               c1 : in STD_LOGIC;
               s : in STD_LOGIC;
               y : out STD_LOGIC
            );
    end component;
    
begin

    mux0: mux2_1
        Port map(   c0 => b0,
                    c1 => b1,
                    s => s0,
                    y => v0
                 );

    mux1: mux2_1
        Port map(   c0 => b2,
                    c1 => b3,
                    s => s0,
                    y => v1
                 );  
                                
    mux2: mux2_1
        Port map(   c0 => v0,
                    c1 => v1,
                    s => s1,
                    y => y0
                 );
                 
end structural;
