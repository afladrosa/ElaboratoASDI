
-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 18.11.2024 16:38:59 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_mux16_1 is
end tb_mux16_1;

architecture tb of tb_mux16_1 is

    component mux16_1
        port (a0  : in std_logic;
              a1  : in std_logic;
              a2  : in std_logic;
              a3  : in std_logic;
              a4  : in std_logic;
              a5  : in std_logic;
              a6  : in std_logic;
              a7  : in std_logic;
              a8  : in std_logic;
              a9  : in std_logic;
              a10 : in std_logic;
              a11 : in std_logic;
              a12 : in std_logic;
              a13 : in std_logic;
              a14 : in std_logic;
              a15 : in std_logic;
              s00 : in std_logic;
              s11 : in std_logic;
              s22 : in std_logic;
              s33 : in std_logic;
              y00 : out std_logic);
    end component;
    
--    signal input     : STD_LOGIC_VECTOR (0 to 15)    := (others => '0');
--    signal control   : STD_LOGIC_VECTOR (3 downto 0) := (others => '0');
--    signal output    : STD_LOGIC                     := 'U';

    signal a0  : std_logic;
    signal a1  : std_logic;
    signal a2  : std_logic;
    signal a3  : std_logic;
    signal a4  : std_logic;
    signal a5  : std_logic;
    signal a6  : std_logic;
    signal a7  : std_logic;
    signal a8  : std_logic;
    signal a9  : std_logic;
    signal a10 : std_logic;
    signal a11 : std_logic;
    signal a12 : std_logic;
    signal a13 : std_logic;
    signal a14 : std_logic;
    signal a15 : std_logic;
    signal s00 : std_logic;
    signal s11 : std_logic;
    signal s22 : std_logic;
    signal s33 : std_logic;
    signal y00 : std_logic;

begin

    dut : mux16_1
    port map (a0  => a0,
              a1  => a1,
              a2  => a2,
              a3  => a3,
              a4  => a4,
              a5  => a5,
              a6  => a6,
              a7  => a7,
              a8  => a8,
              a9  => a9,
              a10 => a10,
              a11 => a11,
              a12 => a12,
              a13 => a13,
              a14 => a14,
              a15 => a15,
              s00 => s00,
              s11 => s11,
              s22 => s22,
              s33 => s33,
              y00 => y00);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        a0 <= '0';
        a1 <= '0';
        a2 <= '0';
        a3 <= '0';
        a4 <= '0';
        a5 <= '0';
        a6 <= '0';
        a7 <= '0';
        a8 <= '0';
        a9 <= '0';
        a10 <= '0';
        a11 <= '0';
        a12 <= '0';
        a13 <= '0';
        a14 <= '0';
        a15 <= '0';
        s00 <= '0';
        s11 <= '0';
        s22 <= '0';
        s33 <= '0';

        -- EDIT Add stimuli here
        wait for 100 ns;
        
        a1 <= '1';
        s33 <= '1';
        
        wait for 10 ns;
        
        s00 <= '1';
        s22 <= '1';
        s33 <= '0';
        a1 <= '0';
        a5 <= '1';

        wait;
    end process;

--   stim_proc: process begin
--        wait for 100 ns;

        -- input = b0 b1 b2 b3 ... b15
        -- control = s3 s2 s1 s0

--        input    <= "0100000000000000"; -- 4000

--        control <= "0001"; -- ESCE IN HEX
--        wait for 10 ns;

--        control <= "1010"; -- ESCE IN HEX
--        input    <= "0000000000100000"; -- 4000
--        wait for 10 ns;

--        assert output = '1'
--            report "errore NON TI TROVI 1"
--            severity failure;

--        wait;
--    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_mux16_1 of tb_mux16_1 is
    for tb
    end for;
end cfg_tb_mux16_1;