----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 19.11.2024 13:01:55
-- Design Name: 
-- Module Name: mux16_4 - Structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux16_4 is
    Port ( x0 : in STD_LOGIC;
           x1 : in STD_LOGIC;
           x2 : in STD_LOGIC;
           x3 : in STD_LOGIC;
           x4 : in STD_LOGIC;
           x5 : in STD_LOGIC;
           x6 : in STD_LOGIC;
           x7 : in STD_LOGIC;
           x8 : in STD_LOGIC;
           x9 : in STD_LOGIC;
           x10 : in STD_LOGIC;
           x11 : in STD_LOGIC;
           x12 : in STD_LOGIC;
           x13 : in STD_LOGIC;
           x14 : in STD_LOGIC;
           x15 : in STD_LOGIC;
           z0 : in STD_LOGIC;
           z1 : in STD_LOGIC;
           z2 : in STD_LOGIC;
           z3 : in STD_LOGIC;
           z4 : in STD_LOGIC;
           z5 : in STD_LOGIC;
           w0 : out STD_LOGIC;
           w1 : out STD_LOGIC;
           w2 : out STD_LOGIC;
           w3 : out STD_LOGIC);
end mux16_4;

architecture Structural of mux16_4 is
    signal v0 : STD_LOGIC := '0';
    
    component demux1_4
        port(  m : in STD_LOGIC;
               n0 : out STD_LOGIC;
               n1 : out STD_LOGIC;
               n2 : out STD_LOGIC;
               n3 : out STD_LOGIC;
               t0 : in STD_LOGIC;
               t1 : in STD_LOGIC
                );
    end component;
    
     component mux16_1
        port(  a0 : in STD_LOGIC;
               a1 : in STD_LOGIC;
               a2 : in STD_LOGIC;
               a3 : in STD_LOGIC;
               a4 : in STD_LOGIC;
               a5 : in STD_LOGIC;
               a6 : in STD_LOGIC;
               a7 : in STD_LOGIC;
               a8 : in STD_LOGIC;
               a9 : in STD_LOGIC;
               a10 : in STD_LOGIC;
               a11 : in STD_LOGIC;
               a12 : in STD_LOGIC;
               a13 : in STD_LOGIC;
               a14 : in STD_LOGIC;
               a15 : in STD_LOGIC;
               s00 : in STD_LOGIC;
               s11 : in STD_LOGIC;
               s22 : in STD_LOGIC;
               s33 : in STD_LOGIC;
               y00 : out STD_LOGIC
               );
    end component;

begin
    mux: mux16_1
        Port map(   a0=>x0,
                    a1=>x1,
                    a2=>x2,
                    a3=>x3,
                    a4=>x4,
                    a5=>x5,
                    a6=>x6,
                    a7=>x7,
                    a8=>x8,
                    a9=>x9,
                    a10=>x10,
                    a11=>x11,
                    a12=>x12,
                    a13=>x13,
                    a14=>x14,
                    a15=>x15,
                    s00=>z0,
                    s11=>z1,
                    s22=>z2,
                    s33=>z3,
                    y00=>v0           
                    );
            
    demux: demux1_4
        Port map(   m=>v0,
                    n0=>w0,
                    n1=>w1,
                    n2=>w2,
                    n3=>w3,
                    t0=>z4,
                    t1=>z5
                    );         
        
        
end Structural;
