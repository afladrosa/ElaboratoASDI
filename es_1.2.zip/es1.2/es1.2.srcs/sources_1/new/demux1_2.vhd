----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 19.11.2024 13:03:48
-- Design Name: 
-- Module Name: demux1_2 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity demux1_2 is
    Port ( h0 : in STD_LOGIC;
           d0 : out STD_LOGIC;
           d1 : out STD_LOGIC;
           s0 : in STD_LOGIC);
end demux1_2;

architecture Behavioral of demux1_2 is

begin
    d0 <= h0 when s0 = '0' else
        '-';
    d1 <= h0 when s0 = '1' else
        '-';
     




end Behavioral;
