# File saved with Nlview 7.5.8 2022-09-21 7111 VDI=41 GEI=38 GUI=JA:10.0 threadsafe
# 
# non-default properties - (restore without -noprops)
property -colorscheme classic
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 15
property maxzoom 6.25
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #0095ff
property objecthighlight4 #8000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #eb591b
property overlaycolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 4
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 15
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 1
property timelimit 1
#
module new mux16_4 work:mux16_4:NOFILE -nosplit
load symbol demux1_4 work:demux1_4:NOFILE HIERBOX pin m input.left pin n0 output.right pin n1 output.right pin n2 output.right pin n3 output.right pin t0 input.left pin t1 input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol mux16_1 work:mux16_1:NOFILE HIERBOX pin a0 input.left pin a1 input.left pin a10 input.left pin a11 input.left pin a12 input.left pin a13 input.left pin a14 input.left pin a15 input.left pin a2 input.left pin a3 input.left pin a4 input.left pin a5 input.left pin a6 input.left pin a7 input.left pin a8 input.left pin a9 input.left pin s00 input.left pin s11 input.left pin s22 input.left pin s33 input.left pin y00 output.right boxcolor 1 fillcolor 2 minwidth 13%
load symbol demux1_2 work:demux1_2:NOFILE HIERBOX pin d0 output.right pin d1 output.right pin h0 input.left pin s0 input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol demux1_2 work:abstract:NOFILE HIERBOX pin d0 output.right pin d1 output.right pin h0 input.left pin s0 input.left boxcolor 1 fillcolor 2 minwidth 13%
load inst demux demux1_4 work:demux1_4:NOFILE -autohide -attr @cell(#000000) demux1_4 -attr @fillcolor #fafafa -pg 1 -lvl 1 -x 40 -y 58
load inst demux|demux0 demux1_2 work:demux1_2:NOFILE -hier demux -autohide -attr @cell(#000000) demux1_2 -attr @name demux0 -pg 1 -lvl 1 -x 100 -y 78
load inst demux|demux1 demux1_2 work:abstract:NOFILE -hier demux -autohide -attr @cell(#000000) demux1_2 -attr @name demux1 -pg 1 -lvl 2 -x 280 -y 78
load inst demux|demux2 demux1_2 work:abstract:NOFILE -hier demux -autohide -attr @cell(#000000) demux1_2 -attr @name demux2 -pg 1 -lvl 2 -x 280 -y 188
load net demux|d0 -attr @name d0 -pin demux|demux0 d0 -pin demux|demux1 h0
netloc demux|d0 1 1 1 N 88
load net demux|d1 -attr @name d1 -pin demux|demux0 d1 -pin demux|demux2 h0
netloc demux|d1 1 1 1 210 108n
load net demux|m -attr @name m -hierPin demux m -pin demux|demux0 h0
netloc demux|m 1 0 1 N 88
load net demux|n0 -attr @name n0 -hierPin demux n0 -pin demux|demux1 d0
netloc demux|n0 1 2 1 N 88
load net demux|n1 -attr @name n1 -hierPin demux n1 -pin demux|demux1 d1
netloc demux|n1 1 2 1 N 108
load net demux|n2 -attr @name n2 -hierPin demux n2 -pin demux|demux2 d0
netloc demux|n2 1 2 1 N 198
load net demux|n3 -attr @name n3 -hierPin demux n3 -pin demux|demux2 d1
netloc demux|n3 1 2 1 N 218
load net demux|t0 -attr @name t0 -hierPin demux t0 -pin demux|demux0 s0
netloc demux|t0 1 0 1 N 108
load net demux|t1 -attr @name t1 -hierPin demux t1 -pin demux|demux1 s0 -pin demux|demux2 s0
netloc demux|t1 1 0 2 NJ 148 230
levelinfo -pg 1 0 40 440
levelinfo -hier demux * 100 280 *
pagesize -pg 1 -db -bbox -sgen 0 -10 440 290
pagesize -hier demux -db -bbox -sgen 40 28 400 258
show
fullfit
#
# initialize ictrl to current module mux16_4 work:mux16_4:NOFILE
ictrl init topinfo |
