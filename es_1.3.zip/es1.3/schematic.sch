# File saved with Nlview 7.5.8 2022-09-21 7111 VDI=41 GEI=38 GUI=JA:10.0 threadsafe
# 
# non-default properties - (restore without -noprops)
property -colorscheme classic
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 15
property maxzoom 6.25
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #0095ff
property objecthighlight4 #8000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #eb591b
property overlaycolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 4
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 15
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 1
property timelimit 1
#
module new mux16_4 work:mux16_4:NOFILE -nosplit
load symbol demux1_4 work:demux1_4:NOFILE HIERBOX pin m input.left pin n0 output.right pin n1 output.right pin n2 output.right pin n3 output.right pin t0 input.left pin t1 input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol mux16_1 work:mux16_1:NOFILE HIERBOX pin a0 input.left pin a1 input.left pin a10 input.left pin a11 input.left pin a12 input.left pin a13 input.left pin a14 input.left pin a15 input.left pin a2 input.left pin a3 input.left pin a4 input.left pin a5 input.left pin a6 input.left pin a7 input.left pin a8 input.left pin a9 input.left pin s00 input.left pin s11 input.left pin s22 input.left pin s33 input.left pin y00 output.right boxcolor 1 fillcolor 2 minwidth 13%
load port w0 output -pg 1 -lvl 3 -x 580 -y 580
load port w1 output -pg 1 -lvl 3 -x 580 -y 610
load port w2 output -pg 1 -lvl 3 -x 580 -y 640
load port w3 output -pg 1 -lvl 3 -x 580 -y 670
load port x0 input -pg 1 -lvl 0 -x 0 -y 20
load port x1 input -pg 1 -lvl 0 -x 0 -y 50
load port x10 input -pg 1 -lvl 0 -x 0 -y 320
load port x11 input -pg 1 -lvl 0 -x 0 -y 350
load port x12 input -pg 1 -lvl 0 -x 0 -y 380
load port x13 input -pg 1 -lvl 0 -x 0 -y 410
load port x14 input -pg 1 -lvl 0 -x 0 -y 440
load port x15 input -pg 1 -lvl 0 -x 0 -y 470
load port x2 input -pg 1 -lvl 0 -x 0 -y 80
load port x3 input -pg 1 -lvl 0 -x 0 -y 110
load port x4 input -pg 1 -lvl 0 -x 0 -y 140
load port x5 input -pg 1 -lvl 0 -x 0 -y 170
load port x6 input -pg 1 -lvl 0 -x 0 -y 200
load port x7 input -pg 1 -lvl 0 -x 0 -y 230
load port x8 input -pg 1 -lvl 0 -x 0 -y 260
load port x9 input -pg 1 -lvl 0 -x 0 -y 290
load port z0 input -pg 1 -lvl 0 -x 0 -y 500
load port z1 input -pg 1 -lvl 0 -x 0 -y 530
load port z2 input -pg 1 -lvl 0 -x 0 -y 560
load port z3 input -pg 1 -lvl 0 -x 0 -y 590
load port z4 input -pg 1 -lvl 0 -x 0 -y 620
load port z5 input -pg 1 -lvl 0 -x 0 -y 650
load inst demux demux1_4 work:demux1_4:NOFILE -autohide -attr @cell(#000000) demux1_4 -pg 1 -lvl 2 -x 430 -y 590
load inst mux mux16_1 work:mux16_1:NOFILE -autohide -attr @cell(#000000) mux16_1 -pg 1 -lvl 1 -x 260 -y 110
load net w0 -pin demux n0 -port w0
netloc w0 1 2 1 540J 580n
load net w1 -pin demux n1 -port w1
netloc w1 1 2 1 560J 610n
load net w2 -pin demux n2 -port w2
netloc w2 1 2 1 NJ 640
load net w3 -pin demux n3 -port w3
netloc w3 1 2 1 540J 660n
load net x0 -pin mux a0 -port x0
netloc x0 1 0 1 200J 20n
load net x1 -pin mux a1 -port x1
netloc x1 1 0 1 180J 50n
load net x10 -pin mux a10 -port x10
netloc x10 1 0 1 NJ 320
load net x11 -pin mux a11 -port x11
netloc x11 1 0 1 20J 340n
load net x12 -pin mux a12 -port x12
netloc x12 1 0 1 40J 360n
load net x13 -pin mux a13 -port x13
netloc x13 1 0 1 60J 380n
load net x14 -pin mux a14 -port x14
netloc x14 1 0 1 80J 400n
load net x15 -pin mux a15 -port x15
netloc x15 1 0 1 120J 420n
load net x2 -pin mux a2 -port x2
netloc x2 1 0 1 160J 80n
load net x3 -pin mux a3 -port x3
netloc x3 1 0 1 140J 110n
load net x4 -pin mux a4 -port x4
netloc x4 1 0 1 120J 140n
load net x5 -pin mux a5 -port x5
netloc x5 1 0 1 100J 170n
load net x6 -pin mux a6 -port x6
netloc x6 1 0 1 80J 200n
load net x7 -pin mux a7 -port x7
netloc x7 1 0 1 60J 230n
load net x8 -pin mux a8 -port x8
netloc x8 1 0 1 40J 260n
load net x9 -pin mux a9 -port x9
netloc x9 1 0 1 20J 290n
load net y00 -pin demux m -pin mux y00
netloc y00 1 1 1 380 300n
load net z0 -pin mux s00 -port z0
netloc z0 1 0 1 140J 440n
load net z1 -pin mux s11 -port z1
netloc z1 1 0 1 160J 460n
load net z2 -pin mux s22 -port z2
netloc z2 1 0 1 180J 480n
load net z3 -pin mux s33 -port z3
netloc z3 1 0 1 200J 500n
load net z4 -pin demux t0 -port z4
netloc z4 1 0 2 NJ 620 NJ
load net z5 -pin demux t1 -port z5
netloc z5 1 0 2 NJ 650 380J
levelinfo -pg 1 0 260 430 580
pagesize -pg 1 -db -bbox -sgen -80 0 650 700
show
fullfit
#
# initialize ictrl to current module mux16_4 work:mux16_4:NOFILE
ictrl init topinfo |
