# File saved with Nlview 7.5.8 2022-09-21 7111 VDI=41 GEI=38 GUI=JA:10.0 threadsafe
# 
# non-default properties - (restore without -noprops)
property -colorscheme classic
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 12
property maxzoom 5
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #0095ff
property objecthighlight4 #8000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #eb591b
property overlaycolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 4
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 12
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 1
property timelimit 1
#
module new controlUnit work:controlUnit:NOFILE -nosplit
load symbol mux16_4 work:mux16_4:NOFILE HIERBOX pin w0 output.right pin w1 output.right pin w2 output.right pin w3 output.right pin x0 input.left pin x1 input.left pin x10 input.left pin x11 input.left pin x12 input.left pin x13 input.left pin x14 input.left pin x15 input.left pin x2 input.left pin x3 input.left pin x4 input.left pin x5 input.left pin x6 input.left pin x7 input.left pin x8 input.left pin x9 input.left pin z0 input.left pin z1 input.left pin z2 input.left pin z3 input.left pin z4 input.left pin z5 input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol RTL_MUX2 work MUX pin S input.bot pinBus I0 input.left [15:0] pinBus I1 input.left [15:0] pinBus O output.right [15:0] fillcolor 1
load symbol RTL_LATCH work GEN pin CLR input.top pinBus D input.left [15:0] pinBus G input.left [15:0] pinBus Q output.right [15:0] fillcolor 1
load port load_1 input -pg 1 -lvl 0 -x 0 -y 260
load port load_2 input -pg 1 -lvl 0 -x 0 -y 390
load port reset input -pg 1 -lvl 0 -x 0 -y 300
load portBus inp input [7:0] -attr @name inp[7:0] -pg 1 -lvl 0 -x 0 -y 190
load portBus outp output [3:0] -attr @name outp[3:0] -pg 1 -lvl 4 -x 820 -y 240
load portBus sel input [5:0] -attr @name sel[5:0] -pg 1 -lvl 0 -x 0 -y 280
load inst mux mux16_4 work:mux16_4:NOFILE -autohide -attr @cell(#000000) mux16_4 -pg 1 -lvl 3 -x 690 -y 50
load inst tmp_i RTL_MUX2 work -attr @cell(#000000) RTL_MUX -pinBusAttr I0 @name I0[15:0] -pinBusAttr I0 @attr S=1'b1 -pinBusAttr I1 @name I1[15:0] -pinBusAttr I1 @attr S=default -pinBusAttr O @name O[15:0] -pg 1 -lvl 1 -x 300 -y 200
load inst tmp_i__0 RTL_MUX2 work -attr @cell(#000000) RTL_MUX -pinBusAttr I0 @name I0[15:0] -pinBusAttr I0 @attr V=B\"0000000011111111\",\ S=1'b1 -pinBusAttr I1 @name I1[15:0] -pinBusAttr I1 @attr S=default -pinBusAttr O @name O[15:0] -pg 1 -lvl 1 -x 300 -y 380
load inst tmp_reg RTL_LATCH work -attr @cell(#000000) RTL_LATCH -pinBusAttr D @name D[15:0] -pinBusAttr G @name G[15:0] -pinBusAttr Q @name Q[15:0] -pg 1 -lvl 2 -x 460 -y 360
load net <const0> -ground -pin tmp_i__0 I0[15] -pin tmp_i__0 I0[14] -pin tmp_i__0 I0[13] -pin tmp_i__0 I0[12] -pin tmp_i__0 I0[11] -pin tmp_i__0 I0[10] -pin tmp_i__0 I0[9] -pin tmp_i__0 I0[8] -pin tmp_i__0 I1[7] -pin tmp_i__0 I1[6] -pin tmp_i__0 I1[5] -pin tmp_i__0 I1[4] -pin tmp_i__0 I1[3] -pin tmp_i__0 I1[2] -pin tmp_i__0 I1[1] -pin tmp_i__0 I1[0]
load net <const1> -power -pin tmp_i__0 I0[7] -pin tmp_i__0 I0[6] -pin tmp_i__0 I0[5] -pin tmp_i__0 I0[4] -pin tmp_i__0 I0[3] -pin tmp_i__0 I0[2] -pin tmp_i__0 I0[1] -pin tmp_i__0 I0[0]
load net inp[0] -attr @rip inp[0] -port inp[0] -pin tmp_i I0[0] -pin tmp_i I1[8]
load net inp[1] -attr @rip inp[1] -port inp[1] -pin tmp_i I0[1] -pin tmp_i I1[9]
load net inp[2] -attr @rip inp[2] -port inp[2] -pin tmp_i I0[2] -pin tmp_i I1[10]
load net inp[3] -attr @rip inp[3] -port inp[3] -pin tmp_i I0[3] -pin tmp_i I1[11]
load net inp[4] -attr @rip inp[4] -port inp[4] -pin tmp_i I0[4] -pin tmp_i I1[12]
load net inp[5] -attr @rip inp[5] -port inp[5] -pin tmp_i I0[5] -pin tmp_i I1[13]
load net inp[6] -attr @rip inp[6] -port inp[6] -pin tmp_i I0[6] -pin tmp_i I1[14]
load net inp[7] -attr @rip inp[7] -port inp[7] -pin tmp_i I0[7] -pin tmp_i I1[15]
load net load_1 -port load_1 -pin tmp_i S -pin tmp_i__0 S
netloc load_1 1 0 1 40 260n
load net load_2 -port load_2 -pin tmp_i__0 I1[15] -pin tmp_i__0 I1[14] -pin tmp_i__0 I1[13] -pin tmp_i__0 I1[12] -pin tmp_i__0 I1[11] -pin tmp_i__0 I1[10] -pin tmp_i__0 I1[9] -pin tmp_i__0 I1[8]
netloc load_2 1 0 1 20J 390
load net outp[0] -attr @rip 0 -pin mux w0 -port outp[0]
load net outp[1] -attr @rip 1 -pin mux w1 -port outp[1]
load net outp[2] -attr @rip 2 -pin mux w2 -port outp[2]
load net outp[3] -attr @rip 3 -pin mux w3 -port outp[3]
load net reset -port reset -pin tmp_reg CLR
netloc reset 1 0 2 NJ 300 NJ
load net sel[0] -attr @rip sel[0] -pin mux z0 -port sel[0]
load net sel[1] -attr @rip sel[1] -pin mux z1 -port sel[1]
load net sel[2] -attr @rip sel[2] -pin mux z2 -port sel[2]
load net sel[3] -attr @rip sel[3] -pin mux z3 -port sel[3]
load net sel[4] -attr @rip sel[4] -pin mux z4 -port sel[4]
load net sel[5] -attr @rip sel[5] -pin mux z5 -port sel[5]
load net tmp1_out[0] -attr @rip O[0] -pin tmp_i O[0] -pin tmp_reg D[0]
load net tmp1_out[10] -attr @rip O[10] -pin tmp_i O[10] -pin tmp_reg D[10]
load net tmp1_out[11] -attr @rip O[11] -pin tmp_i O[11] -pin tmp_reg D[11]
load net tmp1_out[12] -attr @rip O[12] -pin tmp_i O[12] -pin tmp_reg D[12]
load net tmp1_out[13] -attr @rip O[13] -pin tmp_i O[13] -pin tmp_reg D[13]
load net tmp1_out[14] -attr @rip O[14] -pin tmp_i O[14] -pin tmp_reg D[14]
load net tmp1_out[15] -attr @rip O[15] -pin tmp_i O[15] -pin tmp_reg D[15]
load net tmp1_out[1] -attr @rip O[1] -pin tmp_i O[1] -pin tmp_reg D[1]
load net tmp1_out[2] -attr @rip O[2] -pin tmp_i O[2] -pin tmp_reg D[2]
load net tmp1_out[3] -attr @rip O[3] -pin tmp_i O[3] -pin tmp_reg D[3]
load net tmp1_out[4] -attr @rip O[4] -pin tmp_i O[4] -pin tmp_reg D[4]
load net tmp1_out[5] -attr @rip O[5] -pin tmp_i O[5] -pin tmp_reg D[5]
load net tmp1_out[6] -attr @rip O[6] -pin tmp_i O[6] -pin tmp_reg D[6]
load net tmp1_out[7] -attr @rip O[7] -pin tmp_i O[7] -pin tmp_reg D[7]
load net tmp1_out[8] -attr @rip O[8] -pin tmp_i O[8] -pin tmp_reg D[8]
load net tmp1_out[9] -attr @rip O[9] -pin tmp_i O[9] -pin tmp_reg D[9]
load net tmp[0] -attr @rip O[0] -pin tmp_i__0 O[0] -pin tmp_reg G[0]
load net tmp[10] -attr @rip O[10] -pin tmp_i__0 O[10] -pin tmp_reg G[10]
load net tmp[11] -attr @rip O[11] -pin tmp_i__0 O[11] -pin tmp_reg G[11]
load net tmp[12] -attr @rip O[12] -pin tmp_i__0 O[12] -pin tmp_reg G[12]
load net tmp[13] -attr @rip O[13] -pin tmp_i__0 O[13] -pin tmp_reg G[13]
load net tmp[14] -attr @rip O[14] -pin tmp_i__0 O[14] -pin tmp_reg G[14]
load net tmp[15] -attr @rip O[15] -pin tmp_i__0 O[15] -pin tmp_reg G[15]
load net tmp[1] -attr @rip O[1] -pin tmp_i__0 O[1] -pin tmp_reg G[1]
load net tmp[2] -attr @rip O[2] -pin tmp_i__0 O[2] -pin tmp_reg G[2]
load net tmp[3] -attr @rip O[3] -pin tmp_i__0 O[3] -pin tmp_reg G[3]
load net tmp[4] -attr @rip O[4] -pin tmp_i__0 O[4] -pin tmp_reg G[4]
load net tmp[5] -attr @rip O[5] -pin tmp_i__0 O[5] -pin tmp_reg G[5]
load net tmp[6] -attr @rip O[6] -pin tmp_i__0 O[6] -pin tmp_reg G[6]
load net tmp[7] -attr @rip O[7] -pin tmp_i__0 O[7] -pin tmp_reg G[7]
load net tmp[8] -attr @rip O[8] -pin tmp_i__0 O[8] -pin tmp_reg G[8]
load net tmp[9] -attr @rip O[9] -pin tmp_i__0 O[9] -pin tmp_reg G[9]
load net x0 -attr @rip Q[0] -pin mux x0 -pin tmp_reg Q[0]
load net x1 -attr @rip Q[1] -pin mux x1 -pin tmp_reg Q[1]
load net x10 -attr @rip Q[10] -pin mux x10 -pin tmp_reg Q[10]
load net x11 -attr @rip Q[11] -pin mux x11 -pin tmp_reg Q[11]
load net x12 -attr @rip Q[12] -pin mux x12 -pin tmp_reg Q[12]
load net x13 -attr @rip Q[13] -pin mux x13 -pin tmp_reg Q[13]
load net x14 -attr @rip Q[14] -pin mux x14 -pin tmp_reg Q[14]
load net x15 -attr @rip Q[15] -pin mux x15 -pin tmp_reg Q[15]
load net x2 -attr @rip Q[2] -pin mux x2 -pin tmp_reg Q[2]
load net x3 -attr @rip Q[3] -pin mux x3 -pin tmp_reg Q[3]
load net x4 -attr @rip Q[4] -pin mux x4 -pin tmp_reg Q[4]
load net x5 -attr @rip Q[5] -pin mux x5 -pin tmp_reg Q[5]
load net x6 -attr @rip Q[6] -pin mux x6 -pin tmp_reg Q[6]
load net x7 -attr @rip Q[7] -pin mux x7 -pin tmp_reg Q[7]
load net x8 -attr @rip Q[8] -pin mux x8 -pin tmp_reg Q[8]
load net x9 -attr @rip Q[9] -pin mux x9 -pin tmp_reg Q[9]
load netBundle @inp 8 inp[7] inp[6] inp[5] inp[4] inp[3] inp[2] inp[1] inp[0] -autobundled
netbloc @inp 1 0 1 40 190n
load netBundle @sel 6 sel[5] sel[4] sel[3] sel[2] sel[1] sel[0] -autobundled
netbloc @sel 1 0 3 NJ 280 NJ 280 610
load netBundle @outp 4 outp[3] outp[2] outp[1] outp[0] -autobundled
netbloc @outp 1 3 1 800 240n
load netBundle @tmp1_out 16 tmp1_out[15] tmp1_out[14] tmp1_out[13] tmp1_out[12] tmp1_out[11] tmp1_out[10] tmp1_out[9] tmp1_out[8] tmp1_out[7] tmp1_out[6] tmp1_out[5] tmp1_out[4] tmp1_out[3] tmp1_out[2] tmp1_out[1] tmp1_out[0] -autobundled
netbloc @tmp1_out 1 1 1 430 200n
load netBundle @tmp 16 tmp[15] tmp[14] tmp[13] tmp[12] tmp[11] tmp[10] tmp[9] tmp[8] tmp[7] tmp[6] tmp[5] tmp[4] tmp[3] tmp[2] tmp[1] tmp[0] -autobundled
netbloc @tmp 1 1 1 430 370n
load netBundle @x 16 x15 x14 x13 x12 x11 x10 x9 x8 x7 x6 x5 x4 x3 x2 x1 x0 -autobundled
netbloc @x 1 2 1 630 60n
levelinfo -pg 1 0 300 460 690 820
pagesize -pg 1 -db -bbox -sgen -100 0 930 520
show
fullfit
#
# initialize ictrl to current module controlUnit work:controlUnit:NOFILE
ictrl init topinfo |
