-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 19.11.2024 15:11:23 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_mux4_1 is
end tb_mux4_1;

architecture tb of tb_mux4_1 is

    component mux4_1
        port (b0 : in std_logic;
              b1 : in std_logic;
              b2 : in std_logic;
              b3 : in std_logic;
              s0 : in std_logic;
              s1 : in std_logic;
              y0 : out std_logic);
    end component;

    signal b0 : std_logic;
    signal b1 : std_logic;
    signal b2 : std_logic;
    signal b3 : std_logic;
    signal s0 : std_logic;
    signal s1 : std_logic;
    signal y0 : std_logic;

begin

    dut : mux4_1
    port map (b0 => b0,
              b1 => b1,
              b2 => b2,
              b3 => b3,
              s0 => s0,
              s1 => s1,
              y0 => y0);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        b0 <= '0';
        b1 <= '0';
        b2 <= '0';
        b3 <= '0';
        s0 <= '0';
        s1 <= '0';

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_mux4_1 of tb_mux4_1 is
    for tb
    end for;
end cfg_tb_mux4_1;