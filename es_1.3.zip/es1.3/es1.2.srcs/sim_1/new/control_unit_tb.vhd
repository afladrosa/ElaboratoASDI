-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : Sat, 14 Jun 2025 08:04:49 GMT
-- Request id : cfwk-fed377c2-684d2d213f8e6

library ieee;
use ieee.std_logic_1164.all;

entity tb_sis_tot is
end tb_sis_tot;

architecture tb of tb_sis_tot is

    component sis_tot
        port (reset    : in std_logic;
              load_1   : in std_logic;
              load_2   : in std_logic;
              dato_in  : in std_logic_vector (7 downto 0);
              sel      : in std_logic_vector (5 downto 0);
              dato_out : out std_logic_vector (3 downto 0));
    end component;

    signal reset    : std_logic;
    signal load_1   : std_logic;
    signal load_2   : std_logic;
    signal dato_in  : std_logic_vector (7 downto 0);
    signal sel      : std_logic_vector (5 downto 0);
    signal dato_out : std_logic_vector (3 downto 0);

begin

    dut : sis_tot
    port map (reset    => reset,
              load_1   => load_1,
              load_2   => load_2,
              dato_in  => dato_in,
              sel      => sel,
              dato_out => dato_out);
      
    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        reset <= '0';
        load_1 <= '0';
        load_2 <= '0';
        dato_in <= (others => '0');
        sel <= (others => '0');

        -- EDIT Add stimuli here
        -- Reset iniziale
        reset <= '1';
        wait for 10 ns;
        reset <= '0';

        -- Carica un valore nel primo byte
        load_1 <= '1';
        dato_in <= "11111111";
        wait for 10 ns;
        load_1 <= '0';

        -- Carica un valore nel secondo byte
        load_2 <= '1';
        dato_in <= "11111111";
        wait for 10 ns;
        load_2 <= '0';

        -- Cambia i selettori
        sel <= "111111";
        wait for 10 ns;
        sel <= "111111";

        -- Fine simulazione
        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_sis_tot of tb_sis_tot is
    for tb
    end for;
end cfg_tb_sis_tot;