-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 19.11.2024 15:12:19 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_mux2_1 is
end tb_mux2_1;

architecture tb of tb_mux2_1 is

    component mux2_1
        port (c0 : in std_logic;
              c1 : in std_logic;
              s  : in std_logic;
              y  : out std_logic);
    end component;

    signal c0 : std_logic;
    signal c1 : std_logic;
    signal s  : std_logic;
    signal y  : std_logic;

begin

    dut : mux2_1
    port map (c0 => c0,
              c1 => c1,
              s  => s,
              y  => y);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        c0 <= '0';
        c1 <= '0';
        s <= '0';

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_mux2_1 of tb_mux2_1 is
    for tb
    end for;
end cfg_tb_mux2_1;