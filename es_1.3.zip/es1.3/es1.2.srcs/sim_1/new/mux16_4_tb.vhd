-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 19.11.2024 15:14:25 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_mux16_4 is
end tb_mux16_4;

architecture tb of tb_mux16_4 is

    component mux16_4
        port (x0  : in std_logic;
              x1  : in std_logic;
              x2  : in std_logic;
              x3  : in std_logic;
              x4  : in std_logic;
              x5  : in std_logic;
              x6  : in std_logic;
              x7  : in std_logic;
              x8  : in std_logic;
              x9  : in std_logic;
              x10 : in std_logic;
              x11 : in std_logic;
              x12 : in std_logic;
              x13 : in std_logic;
              x14 : in std_logic;
              x15 : in std_logic;
              z0  : in std_logic;
              z1  : in std_logic;
              z2  : in std_logic;
              z3  : in std_logic;
              z4  : in std_logic;
              z5  : in std_logic;
              w0  : out std_logic;
              w1  : out std_logic;
              w2  : out std_logic;
              w3  : out std_logic);
    end component;

    signal x0  : std_logic;
    signal x1  : std_logic;
    signal x2  : std_logic;
    signal x3  : std_logic;
    signal x4  : std_logic;
    signal x5  : std_logic;
    signal x6  : std_logic;
    signal x7  : std_logic;
    signal x8  : std_logic;
    signal x9  : std_logic;
    signal x10 : std_logic;
    signal x11 : std_logic;
    signal x12 : std_logic;
    signal x13 : std_logic;
    signal x14 : std_logic;
    signal x15 : std_logic;
    signal z0  : std_logic;
    signal z1  : std_logic;
    signal z2  : std_logic;
    signal z3  : std_logic;
    signal z4  : std_logic;
    signal z5  : std_logic;
    signal w0  : std_logic;
    signal w1  : std_logic;
    signal w2  : std_logic;
    signal w3  : std_logic;

begin

    dut : mux16_4
    port map (x0  => x0,
              x1  => x1,
              x2  => x2,
              x3  => x3,
              x4  => x4,
              x5  => x5,
              x6  => x6,
              x7  => x7,
              x8  => x8,
              x9  => x9,
              x10 => x10,
              x11 => x11,
              x12 => x12,
              x13 => x13,
              x14 => x14,
              x15 => x15,
              z0  => z0,
              z1  => z1,
              z2  => z2,
              z3  => z3,
              z4  => z4,
              z5  => z5,
              w0  => w0,
              w1  => w1,
              w2  => w2,
              w3  => w3);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        x0 <= '0';
        x1 <= '0';
        x2 <= '0';
        x3 <= '0';
        x4 <= '0';
        x5 <= '0';
        x6 <= '0';
        x7 <= '0';
        x8 <= '0';
        x9 <= '0';
        x10 <= '0';
        x11 <= '0';
        x12 <= '0';
        x13 <= '0';
        x14 <= '0';
        x15 <= '0';
        z0 <= '0';
        z1 <= '0';
        z2 <= '0';
        z3 <= '0';
        z4 <= '0';
        z5 <= '0';

        -- EDIT Add stimuli here
        
        wait for 100 ns;
        
        x0 <= '1';
        
        wait for 100 ns;
        
        z5 <= '1';

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_mux16_4 of tb_mux16_4 is
    for tb
    end for;
end cfg_tb_mux16_4;