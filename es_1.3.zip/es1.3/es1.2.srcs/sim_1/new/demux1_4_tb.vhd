-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 19.11.2024 15:13:01 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_demux1_4 is
end tb_demux1_4;

architecture tb of tb_demux1_4 is

    component demux1_4
        port (m  : in std_logic;
              n0 : out std_logic;
              n1 : out std_logic;
              n2 : out std_logic;
              n3 : out std_logic;
              t0 : in std_logic;
              t1 : in std_logic);
    end component;

    signal m  : std_logic;
    signal n0 : std_logic;
    signal n1 : std_logic;
    signal n2 : std_logic;
    signal n3 : std_logic;
    signal t0 : std_logic;
    signal t1 : std_logic;

begin

    dut : demux1_4
    port map (m  => m,
              n0 => n0,
              n1 => n1,
              n2 => n2,
              n3 => n3,
              t0 => t0,
              t1 => t1);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        m <= '0';
        t0 <= '0';
        t1 <= '0';

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_demux1_4 of tb_demux1_4 is
    for tb
    end for;
end cfg_tb_demux1_4;