-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : 19.11.2024 15:14:03 UTC

library ieee;
use ieee.std_logic_1164.all;

entity tb_demux1_2 is
end tb_demux1_2;

architecture tb of tb_demux1_2 is

    component demux1_2
        port (h0 : in std_logic;
              d0 : out std_logic;
              d1 : out std_logic;
              s0 : in std_logic);
    end component;

    signal h0 : std_logic;
    signal d0 : std_logic;
    signal d1 : std_logic;
    signal s0 : std_logic;

begin

    dut : demux1_2
    port map (h0 => h0,
              d0 => d0,
              d1 => d1,
              s0 => s0);

    stimuli : process
    begin
        -- EDIT Adapt initialization as needed
        h0 <= '0';
        s0 <= '0';

        -- EDIT Add stimuli here

        wait;
    end process;

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_demux1_2 of tb_demux1_2 is
    for tb
    end for;
end cfg_tb_demux1_2;