----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.06.2025 09:48:42
-- Design Name: 
-- Module Name: sis_tot - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sis_tot is
    Port ( reset : in STD_LOGIC;
           clock : in STD_LOGIC;
           load_1 : in STD_LOGIC;
           load_2 : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           sel : in STD_LOGIC_VECTOR (5 downto 0);
           dato_out : out STD_LOGIC_VECTOR (3 downto 0));
end sis_tot;

architecture Behavioral of sis_tot is

component rete16_4 is
    Port ( x0 : in STD_LOGIC;
           x1 : in STD_LOGIC;
           x2 : in STD_LOGIC;
           x3 : in STD_LOGIC;
           x4 : in STD_LOGIC;
           x5 : in STD_LOGIC;
           x6 : in STD_LOGIC;
           x7 : in STD_LOGIC;
           x8 : in STD_LOGIC;
           x9 : in STD_LOGIC;
           x10 : in STD_LOGIC;
           x11 : in STD_LOGIC;
           x12 : in STD_LOGIC;
           x13 : in STD_LOGIC;
           x14 : in STD_LOGIC;
           x15 : in STD_LOGIC;
           z0 : in STD_LOGIC;
           z1 : in STD_LOGIC;
           z2 : in STD_LOGIC;
           z3 : in STD_LOGIC;
           z4 : in STD_LOGIC;
           z5 : in STD_LOGIC;
           w0 : out STD_LOGIC;
           w1 : out STD_LOGIC;
           w2 : out STD_LOGIC;
           w3 : out STD_LOGIC);
end component rete16_4;

component controlUnit is
    Port ( reset : in STD_LOGIC;
           clock : in STD_LOGIC;
           load_1 : in STD_LOGIC;
           load_2 : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           dato_in_mux : out STD_LOGIC_VECTOR (15 downto 0));
end component controlUnit;

-- definiamo un segnale di appoggio per memorizzare l'input ricevuto dagli switch
signal tmp : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');

begin

    rete: rete16_4
    port map ( x0 => tmp(0),
               x1 => tmp(1),
               x2 => tmp(2),
               x3 => tmp(3),
               x4 => tmp(4),
               x5 => tmp(5),
               x6 => tmp(6),
               x7 => tmp(7),
               x8 => tmp(8),
               x9 => tmp(9),
               x10 => tmp(10),
               x11 => tmp(11),
               x12 => tmp(12),
               x13 => tmp(13),
               x14 => tmp(14),
               x15 => tmp(15),
               z0 => sel(0),
               z1 => sel(1),
               z2 => sel(2),
               z3 => sel(3),
               z4 => sel(4),
               z5 => sel(5),
               w0 => dato_out(0),
               w1 => dato_out(1),
               w2 => dato_out(2),
               w3 => dato_out(3));

    cu: controlUnit
    port map ( reset => reset,
               clock => clock,
               load_1 => load_1,
               load_2 => load_2,
               dato_in => dato_in,
               dato_in_mux => tmp);

end Behavioral;
