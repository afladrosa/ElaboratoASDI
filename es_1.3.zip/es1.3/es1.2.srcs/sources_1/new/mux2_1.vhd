----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 18.11.2024 17:43:57
-- Design Name: 
-- Module Name: mux2_1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux2_1 is
    Port ( c0 : in STD_LOGIC;
           c1 : in STD_LOGIC;
           s : in STD_LOGIC;
           y : out STD_LOGIC);
end mux2_1;

-- Utilizzo del costrutto di conditional signal assignment.
-- qui � come se stessi specificando la tabella di verit� della funzione y
architecture Behavioral of mux2_1 is

begin

    y <= c0 when s = '0' else
         c1 when s = '1' else
         '-';

end Behavioral;
