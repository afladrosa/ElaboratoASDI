----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 19.11.2024 13:12:01
-- Design Name: 
-- Module Name: demux1_4 - Structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity demux1_4 is
    Port ( m : in STD_LOGIC;
           n0 : out STD_LOGIC;
           n1 : out STD_LOGIC;
           n2 : out STD_LOGIC;
           n3 : out STD_LOGIC;
           t0 : in STD_LOGIC;
           t1 : in STD_LOGIC);
end demux1_4;

architecture Structural of demux1_4 is

    signal v0 : STD_LOGIC := '0';
    signal v1 : STD_LOGIC := '0';
    
    component demux1_2
        port(  h0 : in STD_LOGIC;
           d0 : out STD_LOGIC;
           d1 : out STD_LOGIC;
           s0 : in STD_LOGIC
            );
    end component;

begin

    demux0: demux1_2
        Port map(   h0 => m,
                    d0 => v0,
                    d1 => v1,
                    s0 => t0
                 );
    demux1: demux1_2
        Port map(   h0 => v0,
                    d0 => n0,
                    d1 => n1,
                    s0 => t1
                 );
    demux2: demux1_2
        Port map(   h0 => v1,
                    d0 => n2,
                    d1 => n3,
                    s0 => t1
                 );


end Structural;
