----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 27.11.2024 15:22:39
-- Design Name: 
-- Module Name: controlUnit - control_unitArch
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity controlUnit is
    Port ( reset : in STD_LOGIC;
           clock : in STD_LOGIC;
           load_1 : in STD_LOGIC;
           load_2 : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           dato_in_mux : out STD_LOGIC_VECTOR (15 downto 0));
end controlUnit;

architecture Behavioural of controlUnit is

-- definiamo un segnale di appoggio per memorizzare l'input ricevuto dagli switch
signal tmp : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');

begin

    dato_in_mux <= tmp;
    
    process(clock)
    begin
        if rising_edge(clock) then
            -- se reset = 1 poniamo tmp = 0
            if reset = '1' then
                tmp <= (others => '0');
            else
                -- se premiamo il bottone load_1 carichiamo la prima parte dell'ingresso dato
                if load_1 = '1' then
                    tmp(7 downto 0) <= dato_in;
                -- se premiamo il bottone load_2 carichiamo la seconda parte dell'ingresso dato
                elsif load_2 = '1' then
                    tmp(15 downto 8) <= dato_in;
                end if;
            end if;
        end if;
    end process;

end Behavioural;
