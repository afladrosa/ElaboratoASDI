----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 16:37:04
-- Design Name: 
-- Module Name: mem_8_bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mem_8_bit is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           write : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (3 downto 0);
           addr : in STD_LOGIC_VECTOR (3 downto 0);
           dato_out : out STD_LOGIC_VECTOR (3 downto 0));
end mem_8_bit;

architecture Behavioral of mem_8_bit is

-- definisco il tipo memory come un array costituito da 16 array ciascuno da 8 elementi
type memory is array (0 to 15) of std_logic_vector (3 downto 0);

-- definisco il segnale mem che � di tipo memory -> ogni cella � inizializzata a 0
signal mem : memory := (others => (others => '0'));

begin

    process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                mem <= (others => (others => '0'));
            elsif write = '1' then
                mem(to_integer(unsigned(addr))) <= dato_in;
            end if;
        end if;
        
        dato_out <= mem(to_integer(unsigned(addr)));
    end process;

    

end Behavioral;
