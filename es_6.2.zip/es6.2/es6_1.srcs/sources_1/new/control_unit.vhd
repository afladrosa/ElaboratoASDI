----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04.04.2025 17:00:39
-- Design Name: 
-- Module Name: control_unit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity control_unit is
    Port ( start : in STD_LOGIC;
           reset : in STD_LOGIC;
           umax : in STD_LOGIC;
           clock : in STD_LOGIC;
           en_read : in STD_LOGIC;
           read : out STD_LOGIC;
           write : out STD_LOGIC;
           abil_cont : out STD_LOGIC;
           stato_out : out STD_LOGIC_VECTOR(4 downto 0));
end control_unit;

architecture Behavioral of control_unit is

type stato is (IDLE, S0, S1, S2, S3); -- S1 -> read, S2 -> write, S3 -> count
signal stato_attuale: stato := IDLE;
signal stato_prossimo: stato := IDLE;


begin

    control : process(stato_attuale, start, en_read, umax)
    begin
    
        case stato_attuale is
            when IDLE =>
                read <= '0';
                write <= '0';
                abil_cont <= '0';
                
                if start = '1' then
                    stato_prossimo <= S0;
                else
                    stato_prossimo <= IDLE;
                end if;

            when S0 =>
                if en_read = '1' then
                    read <= '1';
                    stato_prossimo <= S1;
                else
                    stato_prossimo <= S0;
                end if;

            when S1 =>
                read <= '0';
                write <= '1';
                stato_prossimo <= S2;

            when S2 =>
                write <= '0';
                abil_cont <= '1';
                stato_prossimo <= S3;

            when S3 =>
                if umax = '1' then
                    stato_prossimo <= IDLE;
                else
                    stato_prossimo <= S0;
                end if;

        end case;
            
    end process;
    
    
    cambio_stato : process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                stato_prossimo <= IDLE;
            else
                stato_attuale <= stato_prossimo;
            end if;
            
            -- debug
            case stato_prossimo is
            
                when IDLE =>
                    stato_out <= "10000";
                    
                when S0 =>
                    stato_out <= "01000";
                    
                when S1 =>
                    stato_out <= "00100";
                    
                when S2 =>
                    stato_out <= "00010";
                    
                when S3 =>
                    stato_out <= "00001";
            
            end case;
            
        end if;
    end process;
    
end Behavioral;
