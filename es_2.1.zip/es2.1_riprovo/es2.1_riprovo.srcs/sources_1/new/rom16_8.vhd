----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 21.11.2024 12:34:51
-- Design Name: 
-- Module Name: rom16_8 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity rom16_8 is
    Port ( addr : in STD_LOGIC_VECTOR (3 downto 0);
           out_rom : out STD_LOGIC_VECTOR (7 downto 0));
end rom16_8;

architecture Behavioral of rom16_8 is

-- definisco il tipo memory come un array costituito da 16 array ciascuno da 8 elementi
type memory is array (0 to 15) of std_logic_vector (7 downto 0);

-- definisco la costante rom16_8 che � di tipo memory -> ogni cella � inizializzata con un valore esadecimale
constant rom : memory := (
    x"11",   -- 00010001
    x"12",   -- 00010010
    x"14",   -- 00010100
    x"18",   -- 00011000
    x"21",   -- 00100001
    x"22",   -- 00100010
    x"24",   -- 00100100
    x"28",   -- 00101000
    x"41",   -- 01000001
    x"42",   -- 01000010
    x"44",   -- 01000100
    x"48",   -- 01001000
    x"81",   -- 10000001
    x"82",   -- 10000010
    x"84",   -- 10000100
    x"88"    -- 10001000
);

begin

    out_rom <= rom(to_integer(unsigned(addr))); -- Restituisce immediatamente il dato corrispondente all'indirizzo

end Behavioral;