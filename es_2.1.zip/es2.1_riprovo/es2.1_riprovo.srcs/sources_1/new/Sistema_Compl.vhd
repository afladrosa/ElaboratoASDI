----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 21.11.2024 12:38:10
-- Design Name: 
-- Module Name: Sistema_Compl - structural
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Sistema_Compl is
    Port ( addr : in STD_LOGIC_VECTOR (3 downto 0);
           out_S : out STD_LOGIC_VECTOR (3 downto 0));
end Sistema_Compl;

architecture structural of Sistema_Compl is

signal tmp : std_logic_vector (7 downto 0) := "00000000";

    component rom16_8
        Port ( addr : in STD_LOGIC_VECTOR (3 downto 0);
               out_rom : out STD_LOGIC_VECTOR (7 downto 0));
    end component;
    
    component M_enc8_4
        Port ( in_M : in STD_LOGIC_VECTOR (7 downto 0);
               out_M : out STD_LOGIC_VECTOR (3 downto 0));       
    end component;

begin

    rom : rom16_8
        Port map(   addr => addr,
                    out_rom => tmp
                 );
                 
    encoder : M_enc8_4
        Port map(   in_M => tmp,
                    out_M => out_S
                 );

end structural;
