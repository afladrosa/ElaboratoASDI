
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity booth_on_board is
  Port ( 
        X, Y: in std_logic_vector(7 downto 0);  -- switch 
        clock: in std_logic;
        reset: in std_logic; -- bottone M18
        start: in std_logic; -- bottone P17
        LED: out std_logic_vector(15 downto 0)
    
    );
end booth_on_board;

architecture Structural of booth_on_board is

   
    signal P_temp: std_logic_vector(15 downto 0);
    signal stop_temp: std_logic;
    signal start_cleared: std_logic;


    

    component molt_booth is
	 port( clock, reset,start: in std_logic;
		   X, Y: in std_logic_vector(7 downto 0);   
		   P: out std_logic_vector(15 downto 0);
		   stop_cu: out std_logic);
    end component;

    
   COMPONENT ButtonDebouncer is
    generic (                       
        CLK_period: integer := 10;  -- periodo del clock (della board) in nanosecondi
        btn_noise_time: integer := 10000000 -- durata stimata dell'oscillazione del bottone in nanosecondi. il valore di default e' 10 millisecondi
    );
    Port ( RST : in STD_LOGIC;
           CLK : in STD_LOGIC;
           BTN : in STD_LOGIC;
           CLEARED_BTN : out STD_LOGIC);
    end component;

  

begin


    bd_start: ButtonDebouncer 
    
    Port map( RST => reset,
           CLK => clock,
           BTN => start,
           CLEARED_BTN => start_cleared
           );


    
    
    booth : molt_booth 
	 port map( 
	       clock => clock,
	       reset => reset,
	       start => start_cleared,
		   X=> X,
		   Y=> Y,  
		   P => P_temp,
		   stop_cu => stop_temp
		   );
    
    LED<=P_temp;
    

    




end Structural;
