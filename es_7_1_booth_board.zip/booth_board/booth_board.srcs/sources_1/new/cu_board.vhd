library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity control_unit is
    Port ( 
	       clock : in  STD_LOGIC;
           reset : in  STD_LOGIC;
           load : in  STD_LOGIC;
	       X : in STD_LOGIC_VECTOR(7 downto 0);
	       Y : in STD_LOGIC_VECTOR(7 downto 0); 
           X_out: out STD_LOGIC_VECTOR(7 downto 0);
           Y_out: out STD_LOGIC_VECTOR(7 downto 0)

			 );
end control_unit;

architecture Behavioral of control_unit is

signal reg_value : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
signal reg_dots, reg_enable : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');

begin



X_out <= reg_value(7 downto 0); 
Y_out <= reg_value(15 downto 8); 


main: process(clock)
begin

	if clock'event and clock = '1' then
	   if reset = '1' then
		  reg_value <= (others => '0');
		  reg_dots <= (others => '0');
		  reg_enable <= (others => '0');
	   else
		  if load = '1' then
			reg_value(7 downto 0) <= X;
		    reg_value(15 downto 8) <= Y;
		  
		  end if;
	 end if;
	end if;

end process;


end Behavioral;
