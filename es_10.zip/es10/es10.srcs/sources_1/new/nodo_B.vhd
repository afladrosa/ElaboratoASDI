----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.05.2025 16:46:26
-- Design Name: 
-- Module Name: nodo_B - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity nodo_B is
Port ( reset : in std_logic;
       clock : in std_logic;
       rxd : in std_logic;
       rts: in std_logic;
       cts : out std_logic;
       dato_out_tot : out std_logic_vector(7 downto 0)
    );
end nodo_B;

architecture Behavioral of nodo_B is

component Rs232RefComp is
    Port ( 
            TXD 	: out std_logic  	:= '1';
            RXD 	: in  std_logic;					
            CLK 	: in  std_logic;					--Master Clock
            DBIN 	: in  std_logic_vector (7 downto 0);--Data Bus in
            DBOUT : out std_logic_vector (7 downto 0);	--Data Bus out
            RDA	: inout std_logic;						--Read Data Available(1 quando il dato � disponibile nel registro rdReg)
            TBE	: inout std_logic 	:= '1';				--Transfer Bus Empty(1 quando il dato da inviare � stato caricato nello shift register)
            RD		: in  std_logic;					--Read Strobe(se 1 significa "leggi" --> fa abbassare RDA)
            WR		: in  std_logic;					--Write Strobe(se 1 significa "scrivi" --> fa abbassare TBE)
            PE		: out std_logic;					--Parity Error Flag
            FE		: out std_logic;					--Frame Error Flag
            OE		: out std_logic;					--Overwrite Error Flag
            RST		: in  std_logic	:= '0');			--Master Reset
end component Rs232RefComp;

component cont_mod_N is
    Generic ( modulo : integer := 16;
              N : integer := 4 -- numero di bit necessari
             );
    Port ( RST : in STD_LOGIC;
           CLK : in STD_LOGIC;
           COUNT : out STD_LOGIC_VECTOR (N-1 downto 0);
           UMAX : out STD_LOGIC;
           ABIL : in STD_LOGIC
          );
end component cont_mod_N;

component mem_8_bit is
Port ( clock : in STD_LOGIC;
       reset : in STD_LOGIC;
       write : in STD_LOGIC;
       dato_in : in STD_LOGIC_VECTOR (7 downto 0);
       addr : in STD_LOGIC_VECTOR (2 downto 0);
       dato_out : out STD_LOGIC_VECTOR (7 downto 0));
end component mem_8_bit;

component control_unit_B is
    Port ( reset : in std_logic;
           clock : in std_logic;
           count : in std_logic_vector(2 downto 0);
           rda : in std_logic;
           rts : in std_logic;
           cts : out std_logic;
           rd : out std_logic;
           write : out std_logic;
           en_count : out std_logic
    );
end component control_unit_B;

signal txd_tmp : std_logic;
signal bus_input : std_logic_vector(7 downto 0);
signal bus_output : std_logic_vector(7 downto 0);
signal rda_tmp : std_logic;
signal tbe_tmp : std_logic;
signal rd_tmp : std_logic;
signal wr_tmp : std_logic;
signal parity : std_logic;
signal frame : std_logic;
signal overwrite : std_logic;
signal count_tmp : std_logic_vector(2 downto 0);
signal umax_tmp : std_logic;
signal en_count_tmp : std_logic;
signal write_tmp : std_logic;

begin

    uart_B: Rs232RefComp
    port map ( --TXD 	=> txd_tmp,
               RXD 	=> rxd,					
               CLK 	=> clock,
               DBIN => "00000000",
               DBOUT => bus_output,
               RDA	=> rda_tmp,
               --TBE	=> tbe_tmp,
               RD => rd_tmp,
               WR => '0',
--               PE => parity,
--               FE => frame,
--               OE => overwrite,
               RST => reset );

    counter_B: cont_mod_N
    generic map ( modulo => 8,
                  N => 3 )
    port map ( RST => reset,
               CLK => clock,
               COUNT => count_tmp,
               UMAX => umax_tmp,
               ABIL => en_count_tmp
              );

    mem_B: mem_8_bit
    port map ( clock => clock,
               reset => reset,
               write => write_tmp,
               dato_in => bus_output,
               addr => count_tmp,
               dato_out => dato_out_tot);

    cu_B: control_unit_B 
    port map ( reset => reset,
               clock => clock,
               count => count_tmp,
               rda => rda_tmp,
               rts => rts,
               cts => cts,
               rd => rd_tmp,
               write => write_tmp,
               en_count => en_count_tmp );

end Behavioral;
