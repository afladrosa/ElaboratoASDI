----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.05.2025 18:14:06
-- Design Name: 
-- Module Name: sis_tot - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sis_tot is
Port ( reset : in std_logic;
       clock : in std_logic;
       start : in std_logic;
       dato_out : out std_logic_vector(7 downto 0)
    );
end sis_tot;

architecture Behavioral of sis_tot is

component nodo_A is
    Port ( reset : in std_logic;
           clock : in std_logic;
           start : in std_logic;
           cts: in std_logic;
           rts : out std_logic;
           txd : out std_logic
    );
end component nodo_A;

component nodo_B is
Port ( reset : in std_logic;
       clock : in std_logic;
       rxd : in std_logic;
       rts: in std_logic;
       cts : out std_logic;
       dato_out_tot : out std_logic_vector(7 downto 0)
    );
end component nodo_B;

signal txd_rxd : std_logic;
signal cts_tmp : std_logic;
signal rts_tmp : std_logic;

begin

    A: nodo_A
    port map ( reset => reset,
               clock => clock,
               start => start,
               cts => cts_tmp,
               rts => rts_tmp,
               txd => txd_rxd
            );

    B: nodo_B 
    port map ( reset => reset,
               clock => clock,
               rxd => txd_rxd,
               rts => rts_tmp,
               cts => cts_tmp,
               dato_out_tot => dato_out 
              );

end Behavioral;
