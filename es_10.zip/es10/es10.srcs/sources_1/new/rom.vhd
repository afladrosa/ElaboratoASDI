library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity rom_8_bit is
    Port ( clock : in STD_LOGIC;
           read : in STD_LOGIC;
           addr : in STD_LOGIC_VECTOR(2 downto 0);  -- supponeno di avere N=8 locazioni usiamo 3 bit per rappresentare gli indirizzi
           dato : out STD_LOGIC_VECTOR(7 downto 0));
end rom_8_bit;

architecture Behavioral of rom_8_bit is

-- definisco il tipo memory come un array costituito da 16 array ciascuno da 8 elementi
type memory is array (0 to 7) of std_logic_vector (7 downto 0);

-- definisco la costante rom16_8 che � di tipo memory -> ogni cella � inizializzata con un valore esadecimale
constant rom : memory := (
    x"11",   -- 00010001
    x"12",   -- 00010010
    x"14",   -- 00010100
    x"18",   -- 00011000
    x"21",   -- 00100001
    x"22",   -- 00100010
    x"24",   -- 00100100
    x"28"    -- 00101000
);

begin

    process(clock)
    begin
        if rising_edge(clock) then
            if read <= '1' then
                dato <= rom(to_integer(unsigned(addr)));
            else
                dato <= (others => '-');
            end if;
        end if;
    end process;        

end Behavioral;