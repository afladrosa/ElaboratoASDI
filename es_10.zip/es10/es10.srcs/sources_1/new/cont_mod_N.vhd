library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity cont_mod_N is
    Generic ( modulo : integer := 16;
              N : integer := 4 -- numero di bit necessari
             );
    Port ( RST : in STD_LOGIC;
           CLK : in STD_LOGIC;
           COUNT : out STD_LOGIC_VECTOR (N-1 downto 0);
           UMAX : out STD_LOGIC;
           ABIL : in STD_LOGIC
          );
end cont_mod_N;

architecture Behavioral of cont_mod_N is
    
    signal counter_val : std_logic_vector (N-1 downto 0) := (others => '0');
    signal umax_tmp : std_logic := '0';

begin

    process(CLK)
    begin
        if rising_edge(CLK) then
            if RST = '1' then
                counter_val <= (others => '0');
                umax_tmp <= '0';
                
            elsif ABIL = '1' then
                if (counter_val = std_logic_vector(TO_UNSIGNED(modulo-1,N))) then
                    umax_tmp <= '1';
                    counter_val <= (others => '0');
                else
                    counter_val <= std_logic_vector(unsigned(counter_val) + 1);
                    umax_tmp <= '0';
                end if;
            end if;             
       end if;
    end process;

    UMAX <= umax_tmp;
    COUNT <= counter_val;

end Behavioral;