----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.05.2025 16:45:20
-- Design Name: 
-- Module Name: nodo_A - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity nodo_A is
    Port ( reset : in std_logic;
           clock : in std_logic;
           start : in std_logic;
           cts: in std_logic;
           rts : out std_logic;
           txd : out std_logic
    );
end nodo_A;

architecture Behavioral of nodo_A is

component Rs232RefComp is
    Port ( 
            TXD 	: out std_logic  	:= '1';
            RXD 	: in  std_logic;					
            CLK 	: in  std_logic;					--Master Clock
            DBIN 	: in  std_logic_vector (7 downto 0);--Data Bus in
            DBOUT : out std_logic_vector (7 downto 0);	--Data Bus out
            RDA	: inout std_logic;						--Read Data Available(1 quando il dato � disponibile nel registro rdReg)
            TBE	: inout std_logic 	:= '1';				--Transfer Bus Empty(1 quando il dato da inviare � stato caricato nello shift register)
            RD		: in  std_logic;					--Read Strobe(se 1 significa "leggi" --> fa abbassare RDA)
            WR		: in  std_logic;					--Write Strobe(se 1 significa "scrivi" --> fa abbassare TBE)
            PE		: out std_logic;					--Parity Error Flag
            FE		: out std_logic;					--Frame Error Flag
            OE		: out std_logic;					--Overwrite Error Flag
            RST		: in  std_logic	:= '0');			--Master Reset
end component Rs232RefComp;

component cont_mod_N is
    Generic ( modulo : integer := 16;
              N : integer := 4 -- numero di bit necessari
             );
    Port ( RST : in STD_LOGIC;
           CLK : in STD_LOGIC;
           COUNT : out STD_LOGIC_VECTOR (N-1 downto 0);
           UMAX : out STD_LOGIC;
           ABIL : in STD_LOGIC
          );
end component cont_mod_N;

component rom_8_bit is
    Port ( clock : in STD_LOGIC;
           read : in STD_LOGIC;
           addr : in STD_LOGIC_VECTOR(2 downto 0);  -- supponeno di avere N=8 locazioni usiamo 3 bit per rappresentare gli indirizzi
           dato : out STD_LOGIC_VECTOR(7 downto 0));
end component rom_8_bit;

component control_unit_A is
    Port ( reset : in std_logic;
           clock : in std_logic;
           start : in std_logic;
           count : in std_logic_vector(2 downto 0);
           tbe : in std_logic;
           cts : in std_logic;
           rts : out std_logic;
           wr : out std_logic;
           read : out std_logic;
           en_count : out std_logic
    );
end component control_unit_A;

signal rxd_tmp : std_logic;
signal bus_input : std_logic_vector(7 downto 0);
signal bus_output : std_logic_vector(7 downto 0);
signal rda_tmp : std_logic;
signal tbe_tmp : std_logic;
signal rd_tmp : std_logic;
signal wr_tmp : std_logic;
signal parity : std_logic;
signal frame : std_logic;
signal overwrite : std_logic;
signal count_tmp : std_logic_vector(2 downto 0);
signal umax_tmp : std_logic;
signal en_count_tmp : std_logic;
signal read_tmp : std_logic;

begin

    uart_A: Rs232RefComp
    port map ( TXD 	=> txd,
               RXD 	=> '0',					
               CLK 	=> clock,
               DBIN => bus_input,
               --DBOUT => bus_output,
               --RDA	=> rda_tmp,
               TBE	=> tbe_tmp,
               RD => '1',
               WR => wr_tmp,
               --PE => parity,
               --FE => frame,
               --OE => overwrite,
               RST => reset );

    counter_A: cont_mod_N
    generic map ( modulo => 8,
                  N => 3 )
    port map ( RST => reset,
               CLK => clock,
               COUNT => count_tmp,
               UMAX => umax_tmp,
               ABIL => en_count_tmp
              );

    rom_A: rom_8_bit 
    port map ( clock => clock,
               read => read_tmp,
               addr => count_tmp,
               dato => bus_input);

    cu_A: control_unit_A 
    port map ( reset => reset,
               clock => clock,
               start => start,
               count => count_tmp,
               tbe => tbe_tmp,
               cts => cts,
               rts => rts,
               wr => wr_tmp,
               read => read_tmp,
               en_count => en_count_tmp
            );

end Behavioral;
