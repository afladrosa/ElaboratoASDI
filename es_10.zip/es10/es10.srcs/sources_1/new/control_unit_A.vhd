----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.05.2025 17:32:44
-- Design Name: 
-- Module Name: control_unit_A - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity control_unit_A is
    Port ( reset : in std_logic;
           clock : in std_logic;
           start : in std_logic;
           count : in std_logic_vector(2 downto 0);
           tbe : in std_logic;
           cts : in std_logic;
           rts : out std_logic;
           wr : out std_logic;
           read : out std_logic;
           en_count : out std_logic
    );
end control_unit_A;

architecture Behavioral of control_unit_A is

type state is (IDLE, AVVIA_LETTURA, INVIA_RICHIESTA, WAIT_B, AVVIA_TRASFERIMENTO, ATTENDI_TBE, INCR_COUNT);
signal current_state, next_state : state := IDLE;

begin

    cambia_stato: process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                current_state <= IDLE;
            else
                current_state <= next_state;
            end if; 
        end if;
    end process;
    
    trasmissione : process(current_state, start, tbe, cts)
    begin
        read <= '0';
    
        case current_state is
            when IDLE =>
                en_count <= '0';
                if start = '0' then
                    next_state <= IDLE;
                else
                    next_state <= AVVIA_LETTURA;
                end if;
            
             when AVVIA_LETTURA =>
                en_count <= '0';
                read <= '1';
                next_state <= INVIA_RICHIESTA;
                
            when INVIA_RICHIESTA =>
                read <= '0';
                rts <= '1'; 
                if cts = '0' then
                    next_state <= INVIA_RICHIESTA;
                else
                    next_state <= WAIT_B;
                end if;
            
            when WAIT_B =>
                rts <= '0';
                if cts = '1' then
                    next_state <= WAIT_B;
                else
                    next_state <= AVVIA_TRASFERIMENTO;
                end if;
                
            when AVVIA_TRASFERIMENTO =>
                wr <= '1';
                next_state <= ATTENDI_TBE;
                
            when ATTENDI_TBE =>
                wr <= '0';
                if tbe = '1' then 
                    next_state <= INCR_COUNT;
                else
                    next_state <= ATTENDI_TBE;
                end if;
                    
            when INCR_COUNT =>
                en_count<='1';
                if count="111" then
                    next_state <= IDLE;
                 else 
                    next_state <= AVVIA_LETTURA;
                end if;
                                        
           end case;
     end process;

end Behavioral;
