----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 14.05.2025 17:44:34
-- Design Name: 
-- Module Name: control_unit_B - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity control_unit_B is
    Port ( reset : in std_logic;
           clock : in std_logic;
           count : in std_logic_vector(2 downto 0);
           rda : in std_logic;
           rts : in std_logic;
           cts : out std_logic;
           rd : out std_logic;
           write : out std_logic;
           en_count : out std_logic
    );
end control_unit_B;

architecture Behavioral of control_unit_B is

type state is (IDLE, AVVIA_RICEZIONE, ATTENDI_RDA, LETTURA_UART, SCRITTURA_MEM, INCR_COUNT);
signal current_state, next_state : state := IDLE;

begin

    cambia_stato: process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                current_state <= IDLE;
            else
                current_state <= next_state;
            end if; 
        end if;
    end process;
    
    ricezione : process(current_state, rda, rts)
    begin
       
        case current_state is
                        
            when IDLE => 
                en_count <= '0';
                if rts = '1' then
                    next_state <= AVVIA_RICEZIONE;
                else
                    next_state <= IDLE;
                end if;
            
            when AVVIA_RICEZIONE =>
                cts <= '1';
                if rts = '1' then
                    next_state <= AVVIA_RICEZIONE;
                else
                    next_state <= ATTENDI_RDA;
                end if;
                
           when ATTENDI_RDA=>
                cts <= '0';
                if rda = '0' then
                    next_state <= ATTENDI_RDA;
                else
                    next_state <= LETTURA_UART;
                end if;
                    
           when LETTURA_UART =>
                rd <= '1';
                next_state <= SCRITTURA_MEM;
                
           when SCRITTURA_MEM =>
                write <= '1';
                rd <= '0';
                next_state <= INCR_COUNT;
                
           when INCR_COUNT =>
                write <= '0';
                en_count <= '1';
                next_state <= IDLE;
                
           end case;
     end process;

end Behavioral;
