library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity mem_8_bit is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           write : in STD_LOGIC;
           dato_in : in STD_LOGIC_VECTOR (7 downto 0);
           addr : in STD_LOGIC_VECTOR (2 downto 0);
           dato_out : out STD_LOGIC_VECTOR (7 downto 0));
end mem_8_bit;

architecture Behavioral of mem_8_bit is

-- definisco il tipo memory come un array costituito da 8 array ciascuno da 8 elementi
type memory is array (0 to 7) of std_logic_vector (7 downto 0);

-- definisco il segnale mem che � di tipo memory -> ogni cella � inizializzata a 0
signal mem : memory := (others => (others => '0'));

begin

    process(clock)
    begin
        if rising_edge(clock) then
            if reset = '1' then
                mem <= (others => (others => '0'));
            elsif write = '1' then
                mem(to_integer(unsigned(addr))) <= dato_in;
            end if;
        end if;
    end process;
    
    dato_out <= mem(to_integer(unsigned(addr)));

end Behavioral;