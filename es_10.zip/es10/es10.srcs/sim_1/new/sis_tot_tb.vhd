-- Testbench automatically generated online
-- at https://vhdl.lapinoo.net
-- Generation date : Wed, 14 May 2025 16:21:07 GMT
-- Request id : cfwk-fed377c2-6824c2f3cceaf

library ieee;
use ieee.std_logic_1164.all;

entity tb_sis_tot is
end tb_sis_tot;

architecture tb of tb_sis_tot is

    component sis_tot
        port (reset    : in std_logic;
              clock    : in std_logic;
              start    : in std_logic;
              dato_out : out std_logic_vector (7 downto 0));
    end component;

    signal reset    : std_logic;
    signal clock    : std_logic;
    signal start    : std_logic;
    signal dato_out : std_logic_vector (7 downto 0);
    
    constant clk_period : time := 0.5 ns;
    signal stop_the_clock: boolean;

begin

    dut : sis_tot
    port map (reset    => reset,
              clock    => clock,
              start    => start,
              dato_out => dato_out);

    stimuli : process
    begin
        -- ***EDIT*** Adapt initialization as needed
        reset <= '1';
        start <= '0';

        -- ***EDIT*** Add stimuli here

        wait for 10 ns;
        reset <= '0';
        
        wait for 10 ns;
        start <= '1';
        
        wait for 10 ns;
        start <= '0';

        wait;
    end process;
    
    -- Clock Generation Process
    clocking: process
     begin
        while not stop_the_clock loop
            clock <= '0', '1' after clk_period / 2;
            wait for clk_period;
        end loop;
        wait for 10 ns;
     end process;   

end tb;

-- Configuration block below is required by some simulators. Usually no need to edit.

configuration cfg_tb_sis_tot of tb_sis_tot is
    for tb
    end for;
end cfg_tb_sis_tot;