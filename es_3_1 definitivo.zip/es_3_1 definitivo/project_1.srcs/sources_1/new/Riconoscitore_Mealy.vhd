library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity Riconoscitore is
	port( i: in std_logic;
		  RST, CLK: in std_logic;
		  Y: out std_logic;
		  M: in std_logic
	);
end Riconoscitore;

architecture Behavioral_2proc of Riconoscitore is

type stato is (IDLE, S0, S1, S2, Q0, Q1, Q2, Q3, Q4);

signal stato_corrente : stato := IDLE;
signal stato_prossimo : stato;
signal last_mode : std_logic := '0';

signal Ytemp : std_logic;

begin


stato_uscita: process(stato_corrente, i,m)

begin
    case stato_corrente is
        WHEN IDLE =>
            if m='1' then
                stato_prossimo <= S0;
            elsif m='0' then
                stato_prossimo <= Q0;
            else 
                stato_prossimo<=IDLE;
           end if;
         
         WHEN S0 =>
            if i='0' then
                stato_prossimo<=S0;
                Ytemp<='0';
            elsif i='1'then 
                stato_prossimo<=S1;
                Ytemp<='0';
            end if;
        
        WHEN S1 =>
            if i='0' then
                stato_prossimo<=S2;
                Ytemp<='0';
            elsif i='1' then
                stato_prossimo<=S1;
                Ytemp<='0';
            end if;
        WHEN S2 =>
            if i='0' then
                stato_prossimo<=S0;
                Ytemp<='0';
            elsif i='1' then
                stato_prossimo<=S0;
                Ytemp<='1';
             end if;
         
         WHEN Q0 =>
            if i='0' then
                stato_prossimo<=Q1;
                Ytemp<='0';
            elsif i='1' then
                stato_prossimo<=Q3;
                Ytemp<='0';
            end if;
         
         
         WHEN Q1 => 
            stato_prossimo <= Q2;
            Ytemp<='0';
         
         WHEN Q2 =>
            stato_prossimo <= Q0;
            Ytemp<='0';
         
         WHEN Q3 =>
            if i='1' then
                stato_prossimo <= Q2;
                Ytemp<='0';
            elsif i='0' then
                stato_prossimo <= Q4;
                Ytemp<='0';
            end if;
          
          WHEN Q4 =>
            if i='1' then
                stato_prossimo<=Q0;
                Ytemp<='1';
            elsif i='0' then
                stato_prossimo<=Q0;
                Ytemp<='0';
            end if;   
         
         
         
         end case;               
       


end process;



--stato_uscita: process(stato_corrente, i,m)



--    begin
--    if m /= last_mode then
--	       stato_prossimo<= S0;
--	       Y<='0';
--	       -- in corrispondenza del cambio di modalit� viene 
--	       --anche letto l'ingresso i che viene considerato
--	       -- il primo elemento della sequenza
--	       if m='1' then                       
--	           if i='1' then
--	               stato_prossimo<=S1;
--	               Y<='0';
--	           else
--	               stato_prossimo<=S0;
--	               Y<='0';
--	           end if;
--	       else
--	           if i='1' then
--	               stato_prossimo<=S1;
--	               Y<='0';
--	           else
--	               stato_prossimo<=Q1;
--	               Y<='0';
--	           end if;
--	        end if;
	           
--	   else
--	       if m='1' then 
--	           case stato_corrente is
--	               when S0 =>
--	                   if( i = '0' ) then
--                              stato_prossimo <= S0;
--                               Y <= '0';
--                            else 
--                                stato_prossimo <= S1;
--                                Y <= '0';
--                            end if;

                        
                   
--                when S1 =>
--                        if( i = '0' ) then
--                            stato_prossimo <= S2;
--                            Y <= '0';
--                        else
--                            stato_prossimo <= S1;
--                            Y <= '0';
                            
--                        end if;
                        
                        
--                when S2 =>
--                       if( i = '0' ) then
--                            stato_prossimo <= S0;
--                            Y <= '0';
--                        else
--                            stato_prossimo <= S0;
--                            Y <= '1';
--                        end if;
--                 when others =>
--                        stato_prossimo <= S0;  -- Stato di default per sicurezza
--                        Y <= '0';
                    

                                     
--                 end case;
--            else -- se M=0
                
--                case stato_corrente is
--	               when S0 =>
--	                   if( i = '0' ) then
--                              stato_prossimo <= Q1;
--                               Y <= '0';
--                            else 
--                                stato_prossimo <= S1;
--                                Y <= '0';
--                            end if;

                        
                   
--                when S1 =>
--                        if( i = '0' ) then
--                            stato_prossimo <= S2;
--                            Y <= '0';
--                        else
--                            stato_prossimo <= Q2;
--                            Y <= '0';
                            
--                        end if;
                        
                        
--                when S2 =>
--                       if( i = '0' ) then
--                            stato_prossimo <= S0;
--                            Y <= '0';
--                        else
--                            stato_prossimo <= S0;
--                            Y <= '1';
--                        end if;
                
--                when Q1 =>
--                        stato_prossimo <= Q2;
--                        Y<='0';
--                 when Q2 =>
--                        stato_prossimo <= S0;
--                        Y<='0';
                  

                                     
--                 end case;
--            end if;
--          end if;

   
--end process;


-- questo processo rappresenta gli elementi di memoria 
mem: process (CLK)
begin
	if( CLK'event and CLK = '1' ) then
		if( RST = '1') then
	       stato_corrente <= IDLE;
	       last_mode<=m;
	    else	       
	       if m /= last_mode then
--	           if m ='1' then
--	               stato_corrente<=S0;
--	            elsif m='0' then
--	               stato_corrente<=Q0;
--	            end if;
                stato_corrente<=IDLE;
	         else
	           stato_corrente <= stato_prossimo;
	            Y<=Ytemp;
	            
	         end if;
	       end if;
	       last_mode<=m;
   end if;
end process;


end Behavioral_2proc;


