library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;

entity Riconoscitore_tb is
end;

architecture bench of Riconoscitore_tb is

  component Riconoscitore
  	port( i: in std_logic;
  		  RST, CLK: in std_logic;
  		  Y: out std_logic;
  		  M: in std_logic
  	);
  end component;

  signal d: std_logic;
  signal RST, CLK: std_logic;
  signal Y: std_logic;
  signal M: std_logic ;

  constant clock_period: time := 10 ns;
  signal stop_the_clock: boolean;

begin

  uut: Riconoscitore port map ( i   => d,
                                      RST => RST,
                                      CLK => CLK,
                                      Y   => Y,
                                      M   => M );

  stimulus: process
  begin
    wait for 100 ns;	-- hold reset state for 100 ns.

      
        m<='1';
		d<='1';
		wait for 10 ns;
		d<='0';
		wait for 10 ns;
		d<='1';
		wait for 10 ns;
		d<='0';
		wait for 10 ns;
		d<='1';
		wait for 10 ns;
		d<='1';
		wait for 10 ns;
		d<='0';
		wait for 10 ns;
		d<='0';
        
        --CAMBIO M = 0
        wait for 100 ns;
        m <= '0'; 
        d <= '0';
        wait for 5 ns;
        m<='1';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '0';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '0';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '0';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '0';
        wait for 10 ns;
        d <= '1';
        wait for 10 ns;
        d <= '0';


    stop_the_clock <= true;
    wait;
  end process;

clocking: process
  begin
   while not stop_the_clock loop
      CLK <= '0', '1' after clock_period / 2;
      wait for clock_period;
    end loop;
    wait;
  end process;



end;