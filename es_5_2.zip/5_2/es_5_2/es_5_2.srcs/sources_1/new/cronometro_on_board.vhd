library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity cronometro_on_board is
  Port ( 
        clock: in std_logic;
        reset: in std_logic; -- bottone N17
        set_btn: in std_logic; -- bottone M18
        SW: in std_logic_vector(5 downto 0);
--        minutes_in: in std_logic_vector(5 downto 0);
--        seconds_in: in std_logic_vector(5 downto 0);
--        hours_in: in std_logic_vector(4 downto 0);
        load_sec: in std_logic; -- bottone P17 
        load_min: in std_logic; -- bottone M17
        load_h: in std_logic; -- bottone P18
        anodes : out  STD_LOGIC_VECTOR (7 downto 0); --anodi e catodi delle cifre, sono un output del topmodule
		cathodes : out  STD_LOGIC_VECTOR (7 downto 0)

     
    
   );
end cronometro_on_board;

architecture Structural of cronometro_on_board is

        signal value_temp : std_logic_vector(16 downto 0);
        signal value_encoded : std_logic_vector(31 downto 0);
        
        signal cleared_set: std_logic;
        signal sec_set: std_logic_vector(5 downto 0);
        signal min_set: std_logic_vector(5 downto 0);
        signal h_set: std_logic_vector(4 downto 0);
        


        component cronometro is 
        Port ( 
            clock: in std_logic;
            reset: in std_logic;
            set: in std_logic;
            minutes_in: in std_logic_vector(5 downto 0);
            seconds_in: in std_logic_vector(5 downto 0);
            hours_in: in std_logic_vector(4 downto 0);
            seconds_out: out std_logic_vector(5 downto 0);
            minutes_out: out std_logic_vector(5 downto 0);
            hours_out: out std_logic_vector(4 downto 0)
           );
        end component;
        
        component ButtonDebouncer is
        generic (                       
            CLK_period: integer := 10;  -- periodo del clock (della board) in nanosecondi
            btn_noise_time: integer := 10000000 -- durata stimata dell'oscillazione del bottone in nanosecondi
                                                -- il valore di default � 10 millisecondi
        );
        Port ( RST : in STD_LOGIC;
               CLK : in STD_LOGIC;
               BTN : in STD_LOGIC;
               CLEARED_BTN : out STD_LOGIC);
        end component;

        
        component display_seven_segments is
        Generic( 
                    clock_frequency_in : integer := 50000000; 
                    clock_frequency_out : integer := 5000000
                    );
        Port ( clock : in  STD_LOGIC;
               reset : in  STD_LOGIC;
               value32_in : in  STD_LOGIC_VECTOR (31 downto 0);
               enable : in  STD_LOGIC_VECTOR (7 downto 0);
               dots : in  STD_LOGIC_VECTOR (7 downto 0);
               anodes : out  STD_LOGIC_VECTOR (7 downto 0);
               cathodes : out  STD_LOGIC_VECTOR (7 downto 0));
        end component;
        
        
        component control_unit is -- gestisce l'acquisizione del tempo settato
        Port ( 
		   clock : in  STD_LOGIC;
           reset : in  STD_LOGIC;
		   load_sec : in  STD_LOGIC;
           load_min : in  STD_LOGIC;
           load_h : in  STD_LOGIC;
		   seconds_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i secondi
		   minutes_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i minuti
		   hours_in : in STD_LOGIC_VECTOR(4 downto 0); --valore acquisito da 6 switch per le ore
           
           seconds_out: out STD_LOGIC_VECTOR(5 downto 0); --valori da mostrare in decimale sul display
		   minutes_out : out STD_LOGIC_VECTOR(5 downto 0); 
		   hours_out : out STD_LOGIC_VECTOR(4 downto 0)
			  );
        end component;
        
        component encoder is
        Port(
               in_sec: in std_logic_vector(5 downto 0); 
               in_min: in std_logic_vector(5 downto 0); 
               in_ore: in std_logic_vector(4 downto 0); 
               value32_out: out  STD_LOGIC_VECTOR (31 downto 0)
            
            );
         end component;
        
begin
    

    TIMER: cronometro 
        port map(
            clock => clock,
            reset => reset,
            set => set_btn,
            minutes_in =>  min_set,
            seconds_in =>sec_set,
            hours_in => h_set,
            seconds_out => value_temp(5 downto 0),
            minutes_out =>value_temp(11 downto 6),
            hours_out => value_temp(16 downto 12)
        );
        
      CU: control_unit
        Port map( 
               clock => clock,
               reset => reset,
               load_sec => load_sec,
               load_min => load_min,
               load_h => load_h,
               seconds_in => SW, --valore acquisito da 6 switch per i secondi
               minutes_in => SW, --valore acquisito da 6 switch per i minuti
               hours_in => SW(4 downto 0), --valore acquisito da 6 switch per le ore
               seconds_out => sec_set,
               minutes_out => min_set,
               hours_out => h_set
               
               );

         seven_segment_array: display_seven_segments GENERIC MAP(
            clock_frequency_in => 100000000, --qui inserisco i parametri effettivi (clock della board e clock in uscita desiderato)
            clock_frequency_out => 500 --inserendo un valore inferiore si vedranno le cifre illuminarsi in sequenza
            )
            PORT MAP(
                clock => clock,
                reset => reset,
                value32_in => value_encoded,
                enable => "00111111", --stabilisco che tutti i display siano accesi 
                dots =>"00010100", 
                anodes => anodes,
                cathodes => cathodes
        );
        
--        bd_set: ButtonDebouncer
--            generic map (                       
--                CLK_period => 10,  -- periodo del clock (della board) in nanosecondi
--                btn_noise_time => 10000000 -- durata stimata dell'oscillazione del bottone in nanosecondi
--                                                    -- il valore di default � 10 millisecondi
--            )
--            Port map ( RST => reset,
--                   CLK => clock,
--                   BTN => set,
--                   CLEARED_BTN => cleared_set
--             );
            
            
        encoder_display: encoder
        Port map(
               in_sec => value_temp(5 downto 0), 
               in_min => value_temp(11 downto 6),
               in_ore => value_temp(16 downto 12),
               value32_out => value_encoded
            );
            

            
           

end Structural;
