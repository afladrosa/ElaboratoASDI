library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- la CU ha il compito di caricare l'ora, il minuto e il secondo da settare
-- in 3 passi e di settare gli enable per i punti e le cifre

entity control_unit is
    Port ( 
		   clock : in  STD_LOGIC;
           reset : in  STD_LOGIC;
		   load_sec : in  STD_LOGIC;
           load_min : in  STD_LOGIC;
           load_h : in  STD_LOGIC;
		   seconds_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i secondi
		   minutes_in : in STD_LOGIC_VECTOR(5 downto 0); --valore acquisito da 6 switch per i minuti
		   hours_in : in STD_LOGIC_VECTOR(4 downto 0); --valore acquisito da 6 switch per le ore
           
           seconds_out: out STD_LOGIC_VECTOR(5 downto 0); --valori da mostrare in decimale sul display
		   minutes_out : out STD_LOGIC_VECTOR(5 downto 0); 
		   hours_out : out STD_LOGIC_VECTOR(4 downto 0)
			  );
end control_unit;

architecture Behavioral of control_unit is

signal reg_value : STD_LOGIC_VECTOR(16 downto 0) := (others => '0');
signal reg_dots, reg_enable : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');

begin



seconds_out <= reg_value(5 downto 0); 
minutes_out <= reg_value(11 downto 6); 
hours_out <= reg_value(16 downto 12); 


main: process(clock)
begin

	if clock'event and clock = '1' then
	   if reset = '1' then
		  reg_value <= (others => '0');
		  reg_dots <= (others => '0');
		  reg_enable <= (others => '0');
	   else
		  if load_sec = '1' then
			reg_value(5 downto 0) <= seconds_in;
		  elsif load_min = '1' then
			reg_value(11 downto 6) <= minutes_in;
		  elsif load_h = '1' then
		    reg_value(16 downto 12) <=hours_in;
		  
		  end if;
	 end if;
	end if;

end process;


end Behavioral;

